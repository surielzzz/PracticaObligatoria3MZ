package models;

import static models.Pedido.precioArreglado;

public class Trabajador {

    //ATRIBUTOS
    private String id_trabajador;
    private String email;
    private String clave;
    private String dni;
    private String nombre;
    private Pedido pedidoAsignado1;
    private Pedido pedidoAsignado2;


    //CONSTRUCTORES
    public Trabajador(String id_trabajador, String email, String clave, String dni, String nombre, Pedido pedidoAsignado1, Pedido pedidoAsignado2) {
        this.id_trabajador = id_trabajador;
        this.email = email;
        this.clave = clave;
        this.dni = dni;
        this.nombre = nombre;
        this.pedidoAsignado1 = pedidoAsignado1;
        this.pedidoAsignado2 = pedidoAsignado2;
    }

    public Trabajador(String nombre, String clave, String email) {
        this.nombre = nombre;
        this.clave = clave;
        this.email = email;
    }

    //Constructor para dar de alta a un trabajador
    public Trabajador(String nombre, String clave, String email, String dni) {
        this.nombre = nombre;
        this.clave = clave;
        this.email = email;
        this.dni = dni;
    }

    private int cuentaPedidos() {
        int contadorPedidos = 0;
        if (getPedidoAsignado1() != null) contadorPedidos++;
        if (getPedidoAsignado2() != null) contadorPedidos++;
        return contadorPedidos;
    }


    //GETTERS Y SETTERS
    public String getId_trabajador() {
        return id_trabajador;
    }

    public void setId_trabajador(String id_trabajador) {
        this.id_trabajador = id_trabajador;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Pedido getPedidoAsignado1() {
        return pedidoAsignado1;
    }

    public void setPedidoAsignado1(Pedido pedidoAsignado1) {
        this.pedidoAsignado1 = pedidoAsignado1;
    }

    public Pedido getPedidoAsignado2() {
        return pedidoAsignado2;
    }

    public void setPedidoAsignado2(Pedido pedidoAsignado2) {
        this.pedidoAsignado2 = pedidoAsignado2;
    }


    //OTROS MÉTODOS
    public int calculaPedidos() {
        int numPedidos = 0;
        if (pedidoAsignado1 != null) numPedidos++;
        if (pedidoAsignado2 != null) numPedidos++;
        return numPedidos;
    }

    public String claveAsteriscos() {
        return "*".repeat(clave.length());
    }


    /*public boolean asignaPedidoAutomatico(Pedido pedido){
        if (Trabajador.)
    }*/

    //VISTAS

    public static String pintaTrabajadores(Trabajador trabajador1, Trabajador trabajador2, Trabajador trabajador3) {
        return "\n ╔════════════════════════════════════════╗\n" +
                "          TRABAJADORES DISPONIBLES        \n" +
                " ╠════════════════════════════════════════╣\n" +
                //Verifica si todos los trabajadores están vacíos:
                ((trabajador1 == null && trabajador2 == null && trabajador3 == null)
                        ? " · NO HAY TRABAJADORES DISPONIBLES · " : "") +
                //Pinta los trabajadores que están activos:
                ((trabajador1 == null) ? "" :
                        String.format("    1. - %s - %d pedidos en proceso\n", trabajador1.getNombre(), trabajador1.cuentaPedidos())) +
                ((trabajador2 == null) ? "" :
                        String.format("    2. - %s - %d pedidos en proceso\n", trabajador2.getNombre(), trabajador2.cuentaPedidos())) +
                ((trabajador3 == null) ? "" :
                        String.format("    3. - %s - %d pedidos en proceso\n", trabajador3.getNombre(), trabajador3.cuentaPedidos())) +
                " ╚════════════════════════════════════════╝\n";
    }



    public String pintaTrabajador() {
        return "\n ╔═════════════════════════════════════════╗\n" +
                "\t  TRABAJADOR/A: " + nombre.toUpperCase() + "   \n" +
                " ╠═════════════════════════════════════════╣\n" +
                "   · Email:  \t\t" + email + "\n" +
                "   · Clave:  \t\t" + claveAsteriscos() + "\n" +
                "   · Nombre:  \t\t" + nombre + "\n" +
                "   · DNI:  \t\t\t" + dni + "\n" +
                " ╚═════════════════════════════════════════╝\n";
    }

}
