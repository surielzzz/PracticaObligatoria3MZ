package models;

import data.ProductoData;

public class Producto {

    //ATRIBUTOS
    private String id_producto;
    private String nombre;
    private float precio;
    private int stock;
    private int cantidad; //cantidad que pide el cliente del producto

    //CONSTRUCTORES
    public Producto(String id_producto, String nombre, float precio, int stock) {
        this.id_producto = id_producto;
        this.nombre = nombre;
        this.precio = precio;
        this.stock = stock;
        cantidad = 0;
    }

    public Producto(String nombre, float precio, int cantidad) {
        this.nombre = nombre;
        this.precio = precio;
        this.cantidad = cantidad;
    }

    public Producto(Producto producto) {
        id_producto = producto.id_producto;
        nombre = producto.nombre;
        precio = producto.precio;
        stock = producto.stock;
        cantidad = 0;
    }


    //GETTERS Y SETTERS
    public String getId_producto() {
        return id_producto;
    }

    public void setId_producto(String id_producto) {
        this.id_producto = id_producto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public int getStock() {return stock;}

    public void setStock(int stock) {
        this.stock = stock;
    }

    public int getCantidad() {return cantidad;}

    public void setCantidad(int cantidad) {this.cantidad = cantidad;}

    //OTROS MÉTODOS

    public void restaStock(Producto producto, int cantidad){
        producto.stock -= cantidad;
    }

    public String precioArreglado(float precio) {
        return String.format("%.2f", precio);
    }




    //VISTAS


}
