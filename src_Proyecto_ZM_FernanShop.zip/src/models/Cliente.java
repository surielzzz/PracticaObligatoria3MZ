package models;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Cliente {

    //ATRIBUTOS
    private String id_cliente;
    private String email;
    private String clave;
    private String dni;
    private String nombre;
    private String apellido;
    private String direccion;
    private String localidad;
    private String provincia;
    private String telefono;
    private Pedido pedido1;
    private Pedido pedido2;
    private int contador;


    //CONSTRUCTORES
    public Cliente(String email, String clave, String dni, String nombre, String apellidos, String direccion, String localidad, String provincia, String telefono) {
        id_cliente = calculaIdCliente();
        this.email = email;
        this.clave = clave;
        this.dni = dni;
        this.nombre = nombre;
        this.apellido = apellidos;
        this.direccion = direccion;
        this.localidad = localidad;
        this.provincia = provincia;
        this.telefono = telefono;
        Pedido pedido1 = null;
        Pedido pedido2 = null;
        contador++;
    }




    //GETTERS Y SETTERS
    public String getId_cliente() {
        return id_cliente;
    }

    public void setId_cliente(String id_cliente) {
        this.id_cliente = id_cliente;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public Pedido getPedido1() {
        return pedido1;
    }

    public void setPedido1(Pedido pedido1) {
        this.pedido1 = pedido1;
    }

    public Pedido getPedido2() {
        return pedido2;
    }

    public void setPedido2(Pedido pedido2) {
        this.pedido2 = pedido2;
    }

    public String getLocalidad() {
        return localidad;
    }

    public void setLocalidad(String localidad) {
        this.localidad = localidad;
    }

    public String getProvincia() {
        return provincia;
    }

    public void setProvincia(String provincia) {
        this.provincia = provincia;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public int getContador() {
        return contador;
    }

    public void setContador(int contador) {
        this.contador = contador;
    }

    //OTROS MÉTODOS
    //metodo para comprobar un email:
    public static boolean validarEmail(String email) {
        // Patrón para validar email
        String patron = "^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\\.[a-zA-Z0-9-.]+$";
        Pattern pattern = Pattern.compile(patron);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
        //TODO: HACER VALIDACIÓN DE QUE ESTE EMAIL NO ESTÉ REGISTRADO EN OTRO CLIENTE.
    }

    //metodo para comprobar la contraseña:
    public static boolean validaClave(String clave1, String clave2) {
        return clave1.equals(clave2);
    }

    //metodo para comprobar el nombre:
    public static boolean validaNombre(String nombre) {
        if (nombre.isEmpty() || nombre.length() > 15) return false;
        for (int i = 0; i < nombre.length(); i++) {
            if (Character.isDigit(nombre.charAt(i))) return false;
        }
        return true;
    }

    //metodo para comprobar el nombre:
    public static boolean validaApellido(String apellido) {
        if (apellido.isEmpty() || apellido.length() > 20) return false;
        for (int i = 0; i < apellido.length(); i++) {
            if (Character.isDigit(apellido.charAt(i))) return false;
        }
        return true;
    }

    //metodo para comprobar un dni:
    public static boolean validaDNI(String dni) {
        if (dni.length() != 9) return false;

        for (int i = 0; i < dni.length() - 1; i++) {
            if (Character.isLetter(dni.charAt(i))) return false;
        }

        String numerosStr = dni.substring(0, 8); //obtener los primeros 8 digitos
        char letra = dni.charAt(8); //obtener la letra

        int numId = Integer.parseInt(numerosStr);
        int restoId = numId % 23;
        String listaLetras = "TRWAGMYFPDXBNJZSQVHLCKE";
        char dniLetra = listaLetras.charAt(restoId);

        String letraUltima = String.valueOf(letra);

        //si el ID es correcto, el código sigue y no me muestra ningún mensaje
        return letraUltima.equalsIgnoreCase(String.valueOf(dniLetra));
    }

    public static boolean validaDireccion(String direccion) {
        return direccion.isEmpty();
    }

    public String calculaIdCliente() {
        String id_cliente = "";
        if (dni != null) id_cliente += dni.substring(6, 8);
        id_cliente += "-ZM-00";
        id_cliente += contador;
        return id_cliente;
    }

    public String claveAsteriscos() {
        return "*".repeat(clave.length());
    }

    public static boolean validaLocalidad(String localidad) {
        return localidad.isEmpty();
    }

    public static boolean validaProvincia(String provincia) {
        return provincia.isEmpty();
    }

    public static boolean validaTelefono(String telefono) {
        if (telefono.isEmpty()) return false;
        if (telefono.length() != 9) return false;
        for (int i = 0; i < telefono.length(); i++) {
            if (Character.isLetter(telefono.charAt(i))) return false;
        }
        return true;
    }



    //VISTAS
    @Override
    public String toString() {
        return "Cliente{" +
                "id_cliente='" + calculaIdCliente() + '\'' +
                ", email='" + email + '\'' +
                ", clave='" + clave + '\'' +
                ", dni='" + dni + '\'' +
                ", nombre='" + nombre + '\'' +
                ", apellidos='" + apellido + '\'' +
                ", direccion='" + direccion + '\'' +
                ", pedido1=" + pedido1 +
                ", pedido2=" + pedido2 +
                '}';
    }

    public String pintaCliente() {
        return "\n ╔═════════════════════════════════════════╗\n" +
                "\t INFORMACIÓN DE " + nombre.toUpperCase() + "   \n" +
                " ╠═════════════════════════════════════════╣\n" +
                "   · Email:  \t\t" + email + "\n" +
                "   · Clave:  \t\t" + claveAsteriscos() + "\n" +
                "   · Nombre:  \t\t" + nombre + "\n" +
                "   · Apellido:  \t" + apellido + "\n" +
                "   · DNI:  \t\t" + dni + "\n" +
                "   · Dirección:  \t" + direccion + "\n" +
                "   · Localidad:  \t" + localidad + "\n" +
                "   · Provincia:  \t" + provincia + "\n" +
                "   · Teléfono:  \t" + telefono + "\n" +
                " ╚═════════════════════════════════════════╝\n";
    }

    public int cuentaStock(Pedido pedido) {
        int contadorStock = 0;
        if (pedido.getProducto1() != null) contadorStock += pedido.getProducto1().getCantidad();
        if (pedido.getProducto2() != null) contadorStock += pedido.getProducto2().getCantidad();
        if (pedido.getProducto3() != null) contadorStock += pedido.getProducto3().getCantidad();
        return contadorStock;
    }
}
