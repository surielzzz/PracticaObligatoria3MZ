package models;

import data.ProductoData;
import utils.Utils;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class Pedido {

    //ATRIBUTOS
    private Producto producto1;
    private Producto producto2;
    private Producto producto3;
    private LocalDate fechaPedido;
    private LocalDate fechaEstimada;
    private LocalTime horaPedido;
    private String estado;
    private String comentario;
    private String id_pedido;
    private static int contador = 0;
    private int numPedido;
    private Cliente cliente;


    //CONSTRUCTORES
    public Pedido(Cliente cliente) {
        fechaPedido = LocalDate.now();
        fechaEstimada = calculaFechaEstimada(fechaPedido);
        horaPedido = LocalTime.now();
        estado = "En Preparación";
        contador++;
        numPedido = contador;
        comentario = "";
        id_pedido = calculaIdPedido(cliente);
        producto1 = null;
        producto2 = null;
        producto3 = null;
        this.cliente = cliente;
    }


    //GETTERS Y SETTERS
    public Producto getProducto1() {
        return producto1;
    }

    public void setProducto1(Producto producto1) {
        this.producto1 = producto1;
    }

    public Producto getProducto2() {
        return producto2;
    }

    public void setProducto2(Producto producto2) {
        this.producto2 = producto2;
    }

    public Producto getProducto3() {
        return producto3;
    }

    public void setProducto3(Producto producto3) {
        this.producto3 = producto3;
    }

    public LocalDate getFechaPedido() {
        return fechaPedido;
    }

    public void setFechaPedido(LocalDate fechaPedido) {
        this.fechaPedido = fechaPedido;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

    public String getId_pedido() {
        return id_pedido;
    }

    public void setId_pedido(String id_pedido) {
        this.id_pedido = id_pedido;
    }

    public LocalDate getFechaEstimada() {
        return fechaEstimada;
    }

    public void setFechaEstimada(LocalDate fechaEstimada) {
        this.fechaEstimada = fechaEstimada;
    }

    public int getNumPedido() {
        return numPedido;
    }

    public void setNumPedido(int numPedido) {
        this.numPedido = numPedido;
    }

    public static int getContador() {
        return contador;
    }

    public static void setContador(int contador) {
        Pedido.contador = contador;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    //OTROS MÉTODOS
    public String calculaIdPedido(Cliente cliente) {
        String id_pedido = "";
        id_pedido += "00";
        id_pedido += numPedido;
        id_pedido += "-ZM-";
        id_pedido += horaPedido;
        return id_pedido;
    }

    public LocalDate calculaFechaEstimada(LocalDate fechaPedido){
        return fechaPedido.plusDays(5);
    }

    //método que calcula el precio total de un pedido (calculando los precios de los productos con sus cantidades)
    public static float calculaTotalPedido(Pedido pedido){
        float totalPedido = 0;
        totalPedido += pedido.producto1.getPrecio() * pedido.producto1.getCantidad();
        if (pedido.producto2 != null) totalPedido += pedido.producto2.getPrecio() * pedido.producto2.getCantidad();
        if (pedido.producto3 != null) totalPedido += pedido.producto3.getPrecio() * pedido.producto3.getCantidad();
        return totalPedido;
    }

    public static String precioArreglado(float precio) {
        return String.format("%.2f", precio);
    }


    public static boolean asignaPedidosTrabajador(String opcionPedido, String opcionTrabajador, Pedido pedido1c1, Pedido pedido2c1, Pedido pedido1c2, Pedido pedido2c2, Trabajador trabajador1, Trabajador trabajador2, Trabajador trabajador3){
        Trabajador trabajador = devuelveTrabajadorId(opcionTrabajador, trabajador1, trabajador2, trabajador3);
        if (trabajadorTieneHueco(trabajador)){
            Pedido pedido = devuelvePedidoId(opcionPedido, pedido1c1, pedido2c1, pedido1c2, pedido2c2);
            if (trabajador.getPedidoAsignado1() == null) trabajador.setPedidoAsignado1(pedido);
            else if (trabajador.getPedidoAsignado2() == null) trabajador.setPedidoAsignado2(pedido);
        } else return false;
        return true;
    }

    public static Pedido devuelvePedidoId(String opcionPedido, Pedido pedido1c1, Pedido pedido2c1, Pedido pedido1c2, Pedido pedido2c2){
        Pedido pedido = null;
        switch  (opcionPedido){
            case "1":
                return pedido1c1;
            case "2":
                if (pedido2c1.getNumPedido() == 2) return pedido2c1;
                if (pedido1c2.getNumPedido() == 2) return pedido1c2;
            case "3":
                if (pedido2c1.getNumPedido() == 3) return pedido2c1;
                if (pedido1c2.getNumPedido() == 3) return pedido1c2;
                if (pedido2c2.getNumPedido() == 3) return pedido2c2;
            case "4":
                if (pedido2c1.getNumPedido() == 4) return pedido2c1;
                if (pedido1c2.getNumPedido() == 4) return pedido1c2;
                if (pedido2c2.getNumPedido() == 4) return pedido2c2;
        }
        return pedido;
    }

    public static Trabajador devuelveTrabajadorId(String opcionTrabajador, Trabajador trabajador1, Trabajador trabajador2, Trabajador trabajador3){
        Trabajador trabajador = null;
        return switch (opcionTrabajador) {
            case "1" -> trabajador1;
            case "2" -> trabajador2;
            case "3" -> trabajador3;
            default -> trabajador;
        };
    }

    public static boolean trabajadorTieneHueco(Trabajador trabajador){
        if (trabajador.getPedidoAsignado1() == null) return true;
        if (trabajador.getPedidoAsignado2() == null) return true;
        return false;
    }

    public static String formatearFecha(LocalDate fecha) {
        //define el formato deseado
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        //devuelve la fecha en el formato especificado
        return fecha.format(formato);
    }

    public static boolean esNumero(String num) {
        return num.matches("[0-9]+");
    }

    //metodo para validar si una fecha es válida
    public static boolean esFechaValida(int dia, int mes, int anio) {
        // Validar rango de mes y día
        return mes >= 1 && mes <= 12;
    }


    //VISTAS

    public String pintaPedido(Pedido pedido, Cliente cliente) {
        return "\n ╔═════════════════════════════════════════════════════════╗\n" +
                "               PEDIDO " + id_pedido + "\n" +
                " ╠═════════════════════════════════════════════════════════╣\n" +
                "   · Estado:  \t\t\t" + estado + "\n" +
                "   · Cliente:  \t\t\t" + cliente.getNombre() + "\n" +
                "   · Dirección:  \t\t" + cliente.getDireccion() + "\n" +
                "   · Localidad:  \t\t" + cliente.getLocalidad() + "\n" +
                "   · Provincia:  \t\t" + cliente.getProvincia() + "\n" +
                "   · Teléfono:  \t\t" + cliente.getTelefono() + "\n" +
                "   · Correo:  \t\t\t" + cliente.getEmail() + "\n" +
                "   · Fecha Pedido:  \t\t" + formatearFecha(fechaPedido) + "\n" +
                "   · Entrega Estimada:  \t" + formatearFecha(fechaEstimada) + "\n" +
                "   · Comentarios:  \t\t" + comentario + "\n" +
                "   · Detalles: \n" +
                        "\t\t -" + producto1.getNombre() + " (" + producto1.precioArreglado(producto1.getPrecio()) + "E x" + producto1.getCantidad() + ")" + "\n" +
                ((producto2 == null)? "" :
                        "\t\t -" + producto2.getNombre() + " (" + producto2.precioArreglado(producto2.getPrecio()) + "E x" + producto2.getCantidad() + ")" + "\n" ) +
                ((producto3 == null)? "" :
                        "\t\t -" + producto3.getNombre() + " (" + producto3.precioArreglado(producto3.getPrecio()) + "E x" + producto3.getCantidad() + ")" + "\n" ) +
                " ╠═════════════════════════════════════════════════════════╣\n" +
                "   · TOTAL DEL PEDIDO:  \t\t\t" + precioArreglado(calculaTotalPedido(pedido)) + "E \n" +
                " ╚═════════════════════════════════════════════════════════╝\n";
    }

    public static String pintaPedidosSinAsignar(Cliente cliente1, Cliente cliente2){
        return "\n ╔═══════════════════════════════════════════════════════════════════════════════════════════╗\n" +
                "                                      PEDIDOS POR ASIGNAR\n" +
                " ╠═══════════════════════════════════════════════════════════════════════════════════════════╣\n" +
                //Verifica si todos los pedidos están vacíos:
                ((cliente1.getPedido1() == null && cliente1.getPedido2() == null && cliente2.getPedido1() == null && cliente2.getPedido2() == null)
                        ? " · NO HAY PEDIDOS POR ASIGNAR · " : "") +
                //Pinta los pedidos que están activos:
                ((cliente1 == null || cliente1.getPedido1() == null)? "" :
                        String.format("    %d. - %s - %s %s (%s) - %d productos - %sE \n", cliente1.getPedido1().getNumPedido(), cliente1.getPedido1().getId_pedido(), cliente1.getNombre(),cliente1.getApellido(),cliente1.getProvincia(),cliente1.cuentaStock(cliente1.getPedido1()),precioArreglado(calculaTotalPedido(cliente1.getPedido1())))) +
                ((cliente1 == null || cliente1.getPedido2() == null)? "" :
                        String.format("    %d. - %s - %s %s (%s) - %d productos - %sE \n", cliente1.getPedido2().getNumPedido(), cliente1.getPedido2().getId_pedido(), cliente1.getNombre(),cliente1.getApellido(),cliente1.getProvincia(),cliente1.cuentaStock(cliente1.getPedido2()),precioArreglado(calculaTotalPedido(cliente1.getPedido2())))) +
                ((cliente2 == null || cliente2.getPedido1() == null)? "" :
                        String.format("    %d. - %s - %s %s (%s) - %d productos - %sE \n", cliente2.getPedido1().getNumPedido(), cliente2.getPedido1().getId_pedido(), cliente2.getNombre(),cliente2.getApellido(),cliente2.getProvincia(),cliente2.cuentaStock(cliente2.getPedido1()),precioArreglado(calculaTotalPedido(cliente2.getPedido1())))) +
                ((cliente2 == null || cliente2.getPedido2() == null)? "" :
                        String.format("    %d. - %s - %s %s (%s) - %d productos - %sE \n", cliente2.getPedido2().getNumPedido(), cliente2.getPedido2().getId_pedido(), cliente2.getNombre(),cliente2.getApellido(),cliente2.getProvincia(),cliente2.cuentaStock(cliente2.getPedido2()),precioArreglado(calculaTotalPedido(cliente2.getPedido2())))) +
                " ╚═══════════════════════════════════════════════════════════════════════════════════════════╝\n";
    }


    public static String pintaPedidosTrabajador(Trabajador trabajador){
        return "\n ╔════════════════════════════════════════════════════════════╗\n" +
                "                     PEDIDOS DEL TRABAJADOR\n" +
                " ╠════════════════════════════════════════════════════════════╣\n" +
                //Verifica si todos los pedidos están vacíos:
                ((trabajador.getPedidoAsignado1() == null && trabajador.getPedidoAsignado2() == null)
              ? "                  · NO HAY PEDIDOS ASIGNADOS · " : "") +
                //Pinta los pedidos que están activos:
                ((trabajador.getPedidoAsignado1() == null)? "" :
                        String.format("    1. - Id: %s (%s) \n " +
                                      "      - Nombre: %s %s \n" +
                                      "       - DNI: %s \n" +
                                      "       - Teléfono: %s \n" +
                                      "       - Dirección: %s \n" +
                                      "       - Localidad: %s \n" +
                                      "       - Provincia: %s \n\n",
                                trabajador.getPedidoAsignado1().getId_pedido(),
                                trabajador.getPedidoAsignado1().getEstado(),
                                trabajador.getPedidoAsignado1().getCliente().getNombre(),
                                trabajador.getPedidoAsignado1().getCliente().getApellido(),
                                trabajador.getPedidoAsignado1().getCliente().getDni(),
                                trabajador.getPedidoAsignado1().getCliente().getTelefono(),
                                trabajador.getPedidoAsignado1().getCliente().getDireccion(),
                                trabajador.getPedidoAsignado1().getCliente().getLocalidad(),
                                trabajador.getPedidoAsignado1().getCliente().getProvincia())) +

                ((trabajador.getPedidoAsignado2() == null)? "" :
                        String.format("    2. - Id: %s (%s) \n" +
                                      "      - Nombre: %s %s \n" +
                                      "       - DNI: %s \n" +
                                      "       - Teléfono: %s \n" +
                                      "       - Dirección: %s \n" +
                                      "       - Localidad: %s \n" +
                                      "       - Provincia: %s \n",
                                trabajador.getPedidoAsignado2().getId_pedido(),
                                trabajador.getPedidoAsignado2().getEstado(),
                                trabajador.getPedidoAsignado2().getCliente().getNombre(),
                                trabajador.getPedidoAsignado2().getCliente().getApellido(),
                                trabajador.getPedidoAsignado2().getCliente().getDni(),
                                trabajador.getPedidoAsignado2().getCliente().getTelefono(),
                                trabajador.getPedidoAsignado2().getCliente().getDireccion(),
                                trabajador.getPedidoAsignado2().getCliente().getLocalidad(),
                                trabajador.getPedidoAsignado2().getCliente().getProvincia())) +
                " ╚════════════════════════════════════════════════════════════╝\n";
    }
}
