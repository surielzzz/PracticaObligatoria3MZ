package models;

public class Administrador {

    //ATRIBUTOS
    private String id_administrador;
    private String email;
    private String clave;
    private String dni;
    private String nombre;
    private int pedidosPorAsignar = 0;


    //CONSTRUCTORES
    public Administrador(String id_administrador, String email, String clave, String dni, String nombre) {
        this.id_administrador = id_administrador;
        this.email = email;
        this.clave = clave;
        this.dni = dni;
        this.nombre = nombre;
    }

    public Administrador(String nombre, String clave, String email) {
        this.nombre = nombre;
        this.clave = clave;
        this.email = email;
    }

    //GETTERS Y SETTERS
    public String getId_administrador() {
        return id_administrador;
    }

    public void setId_administrador(String id_administrador) {
        this.id_administrador = id_administrador;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getPedidosPorAsignar() {
        return pedidosPorAsignar;
    }

    public void setPedidosPorAsignar(int pedidosPorAsignar) {
        this.pedidosPorAsignar = pedidosPorAsignar;
    }

    //OTROS MÉTODOS
    public static boolean asignaPedido(Pedido pedido, Trabajador trabajador){
        if(trabajador.getPedidoAsignado1() == null){
            trabajador.setPedidoAsignado1(pedido);
            return true;
        }
        else if(trabajador.getPedidoAsignado2() == null){
            trabajador.setPedidoAsignado2(pedido);
            return true;
        }
        else return false;
    }

    //VISTAS


}
