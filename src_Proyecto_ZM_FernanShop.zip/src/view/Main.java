package view;

import data.ProductoData;
import models.*;
import utils.Menus;
import utils.Utils;

import java.time.LocalDate;
import java.util.Scanner;

import static models.Pedido.esFechaValida;


public class Main {
    public static void main(String[] args) {

        //VARIABLES
        var s = new Scanner(System.in);

        String op1, op2, op3, op4, op5, op6,
                clave = "", clave1, clave2,
                email = "", nombre = "", nombreModificado, apellido = "", apellidoModificado,
                dni = "", direccion, direccionModificado, localidad, localidadModificada,
                provincia, provinciaModificada,
                trabajador1ClaveIntro, trabajador1EmailIntro, //variables del trabajador 1 (para iniciar sesión)
                trabajador2ClaveIntro, trabajador2EmailIntro, //variables del trabajador 2 (para iniciar sesión)
                administradorClaveIntro, administradorEmailIntro, //variables de administrador (para iniciar sesión)
                idPedidoIntro, datoModificado, estado, incluirComentario, comentario,
                opcionPedido, opcionTrabajador,
                cambiarFechaEstimada, telefono, fechaIntro,
                emailTrabajador, clave1Trabajador, clave2Trabajador, dniTrabajador = "", nombreTrabajador = "";
        int unidadesAComprar, dia, mes, anio;

        boolean cantidadValida = true, sesionIniciada = false, iniciaCliente = false,
                esTrabajador1 = false, esTrabajador2 = false, esTrabajador3 = false,
                esAdministrador = false;

        LocalDate fechaEstimadaIntro;

        //Variables de los clientes:
        Cliente cliente1 = null;
        Cliente cliente2 = null;

        //Variables de los trabajadores:
        //Trabajador trabajador1 = new Trabajador("Mireya", "1234", "mireya@gmail.com");
        //Trabajador trabajador2 = new Trabajador("Zamira", "4321", "zamira@gmail.com");
        Trabajador trabajador1 = new Trabajador("Zeus", "5678", "zeus@gmail.com", "12345678z");
        Trabajador trabajador2 = null;
        Trabajador trabajador3 = null;

        //variable administrador:
        Administrador administrador = new Administrador("Carlos", "0000", "carlos@gmail.com");

        //Variables de los pedidos de cada cliente:
        Pedido pedido1c1 = null;
        Pedido pedido2c1 = null;
        Pedido pedido1c2 = null;
        Pedido pedido2c2 = null;

        //Variables de los productos de los pedidos de cada cliente:
        Producto producto1pe1c1 = null;
        Producto producto2pe1c1 = null;
        Producto producto3pe1c1 = null;

        Producto producto1pe2c1 = null;
        Producto producto2pe2c1 = null;
        Producto producto3pe2c1 = null;

        Producto producto1pe1c2 = null;
        Producto producto2pe1c2 = null;
        Producto producto3pe1c2 = null;

        Producto producto1pe2c2 = null;
        Producto producto2pe2c2 = null;
        Producto producto3pe2c2 = null;

        //MOCK:
        //cliente2 = new Cliente("mireya@gmail.com", "1234", "12345678Z", "Mireya", "Cueto", "Calle juasjuas");

        //MAIN
        Menus.logo();

        do {
            Menus.menuPrincipal();
            System.out.print("Introduzca la opción deseada: ");
            op1 = s.nextLine();

            switch (op1) {
                //Iniciar Sesión:
                case "1":
                    do {
                        sesionIniciada = false; //se resetea la variable booleana
                        //SE PIDE LA INFO PARA INICIAR SESIÓN
                        System.out.print("Introduzca su email para iniciar sesión: ");
                        email = s.nextLine();
                        System.out.print("Introduzca su clave para iniciar sesión: ");
                        clave = s.nextLine();

                        //SE COMPRUEBA SI ES EL TRABAJADOR 1:
                        if (trabajador1 != null && email.equalsIgnoreCase(trabajador1.getEmail()) && clave.equalsIgnoreCase(trabajador1.getClave())) {
                            sesionIniciada = true;
                            esTrabajador1 = true;

                            break;
                        }

                        //SE COMPRUEBA SI ES EL TRABAJADOR 2:
                        else if (trabajador2 != null && email.equalsIgnoreCase(trabajador2.getEmail()) && clave.equalsIgnoreCase(trabajador2.getClave())) {
                            sesionIniciada = true;
                            esTrabajador2 = true;
                            break;
                        }

                        //SE COMPRUEBA SI ES EL TRABAJADOR 3:
                        else if (trabajador3 != null && email.equalsIgnoreCase(trabajador3.getEmail()) && clave.equalsIgnoreCase(trabajador3.getClave())) {
                            sesionIniciada = true;
                            esTrabajador3 = true;
                            break;
                        }

                        //SE COMPRUEBA SI ES EL ADMINISTRADOR:
                        else if (email.equalsIgnoreCase(administrador.getEmail()) && clave.equalsIgnoreCase(administrador.getClave())) {
                            sesionIniciada = true;
                            esAdministrador = true;
                            //MENÚ TRABAJADOR:
                            System.out.println("has iniciao sesion");
                            //Menus.menuAdministrador(administrador.getNombre(),);   ---> TODO: HACER MÉTODO PARA CALCULAR LOS PEDIDOS DEL ADMIN

                            break;
                        }

                        //SE INICIA SESIÓN CON UNA CUENTA DE CLIENTE:
                        else {
                            //SE COMPRUEBA SI ES EL CLIENTE 1:
                            if (cliente1 != null && (email.equalsIgnoreCase(cliente1.getEmail()) && clave.equalsIgnoreCase(cliente1.getClave()))) {
                                sesionIniciada = true;
                                //MENÚ CLIENTE:
                                iniciaCliente = true;
                            }

                            //SE COMPRUEBA SI ES EL CLIENTE 2:
                            else if (cliente2 != null && (email.equalsIgnoreCase(cliente2.getEmail()) && clave.equalsIgnoreCase(cliente2.getClave()))) {
                                sesionIniciada = true;
                                //MENÚ CLIENTE:
                                iniciaCliente = true;
                            }

                            //CASO EN EL QUE NO COINCIDAN LOS DATOS CON NINGÚN OBJETO CREADO:
                            else {
                                System.out.println(" - NO SE HA PODIDO INICIAR SESIÓN, CORREO O CLAVE ERRÓNEOS - ");
                            }
                        }
                    } while (!sesionIniciada);

                    //MOSTRAMOS LAS OPCIONES AL TRABAJADOR:
                    if (esTrabajador1 || esTrabajador2 || esTrabajador3) {
                        do {
                            //MENÚ TRABAJADOR:
                            if (esTrabajador1)
                                Menus.menuTrabajador(trabajador1.getNombre(), trabajador1.calculaPedidos());
                            if (esTrabajador2)
                                Menus.menuTrabajador(trabajador2.getNombre(), trabajador2.calculaPedidos());
                            if (esTrabajador3)
                                Menus.menuTrabajador(trabajador3.getNombre(), trabajador3.calculaPedidos());
                            System.out.print("Introduzca una opción: ");
                            op5 = s.nextLine();
                            switch (op5) {
                                case "1":
                                    //CONSULTA DE LOS PEDIDOS ASIGNADOS
                                    //si el trabajador tiene pedidos asignados:
                                    if (esTrabajador1) System.out.println(Pedido.pintaPedidosTrabajador(trabajador1));
                                    if (esTrabajador2) System.out.println(Pedido.pintaPedidosTrabajador(trabajador2));
                                    if (esTrabajador3) System.out.println(Pedido.pintaPedidosTrabajador(trabajador3));
                                    break;

                                case "2":
                                    // MODIFICAR EL ESTADO DE UN PEDIDO
                                    System.out.print("Introduzca el id del pedido que quiere modificar: ");
                                    idPedidoIntro = s.nextLine();

                                    Menus.menuCambiaEstado();
                                    System.out.print("Introduzca el estado al que desea cambiarlo: ");
                                    estado = s.nextLine();

                                    // Cambiar el estado según la opción
                                    switch (estado) {
                                        case "1":
                                            if (pedido1c1 != null && idPedidoIntro.equalsIgnoreCase(pedido1c1.getId_pedido()))
                                                pedido1c1.setEstado("En Preparación");
                                            else if (pedido2c1 != null && idPedidoIntro.equalsIgnoreCase(pedido2c1.getId_pedido()))
                                                pedido2c1.setEstado("En Preparación");
                                            else if (pedido1c2 != null && idPedidoIntro.equalsIgnoreCase(pedido1c2.getId_pedido()))
                                                pedido1c2.setEstado("En Preparación");
                                            else if (pedido2c2 != null && idPedidoIntro.equalsIgnoreCase(pedido2c2.getId_pedido()))
                                                pedido2c2.setEstado("En Preparación");
                                            else System.out.println(" - Ha ocurrido un error -");
                                            break;
                                        case "2":
                                            if (pedido1c1 != null && idPedidoIntro.equalsIgnoreCase(pedido1c1.getId_pedido()))
                                                pedido1c1.setEstado("Enviado");
                                            else if (pedido2c1 != null && idPedidoIntro.equalsIgnoreCase(pedido2c1.getId_pedido()))
                                                pedido2c1.setEstado("Enviado");
                                            else if (pedido1c2 != null && idPedidoIntro.equalsIgnoreCase(pedido1c2.getId_pedido()))
                                                pedido1c2.setEstado("Enviado");
                                            else if (pedido2c2 != null && idPedidoIntro.equalsIgnoreCase(pedido2c2.getId_pedido()))
                                                pedido2c2.setEstado("Enviado");
                                            else System.out.println(" - Ha ocurrido un error -");
                                            break;
                                        case "3":
                                            if (pedido1c1 != null && idPedidoIntro.equalsIgnoreCase(pedido1c1.getId_pedido()))
                                                pedido1c1.setEstado("Cancelado");
                                            else if (pedido2c1 != null && idPedidoIntro.equalsIgnoreCase(pedido2c1.getId_pedido()))
                                                pedido2c1.setEstado("Cancelado");
                                            else if (pedido1c2 != null && idPedidoIntro.equalsIgnoreCase(pedido1c2.getId_pedido()))
                                                pedido1c2.setEstado("Cancelado");
                                            else if (pedido2c2 != null && idPedidoIntro.equalsIgnoreCase(pedido2c2.getId_pedido()))
                                                pedido2c2.setEstado("Cancelado");
                                            else System.out.println(" - Ha ocurrido un error -");
                                            break;
                                        case "4":
                                            if (pedido1c1 != null && idPedidoIntro.equalsIgnoreCase(pedido1c1.getId_pedido()))
                                                pedido1c1.setEstado("Recibido");
                                            else if (pedido2c1 != null && idPedidoIntro.equalsIgnoreCase(pedido2c1.getId_pedido()))
                                                pedido2c1.setEstado("Recibido");
                                            else if (pedido1c2 != null && idPedidoIntro.equalsIgnoreCase(pedido1c2.getId_pedido()))
                                                pedido1c2.setEstado("Recibido");
                                            else if (pedido2c2 != null && idPedidoIntro.equalsIgnoreCase(pedido2c2.getId_pedido()))
                                                pedido2c2.setEstado("Recibido");
                                            else System.out.println(" - Ha ocurrido un error -");
                                            break;
                                        case "5":
                                            if (pedido1c1 != null && idPedidoIntro.equalsIgnoreCase(pedido1c1.getId_pedido()))
                                                pedido1c1.setEstado("Retrasado");
                                            else if (pedido2c1 != null && idPedidoIntro.equalsIgnoreCase(pedido2c1.getId_pedido()))
                                                pedido2c1.setEstado("Retrasado");
                                            else if (pedido1c2 != null && idPedidoIntro.equalsIgnoreCase(pedido1c2.getId_pedido()))
                                                pedido1c2.setEstado("Retrasado");
                                            else if (pedido2c2 != null && idPedidoIntro.equalsIgnoreCase(pedido2c2.getId_pedido()))
                                                pedido2c2.setEstado("Retrasado");
                                            else System.out.println(" - Ha ocurrido un error -");
                                            break;
                                        case "6":
                                            Utils.saliendo(); // Salir del sistema
                                            break;
                                        default:
                                            System.out.println(" · OPCIÓN INTRODUCIDA INCORRECTA ·");
                                            break;
                                    }
                                    //preguntamos por el comentario
                                    System.out.print("  ¿Deseas añadir un comentario a este pedido? (SI/NO): ");
                                    incluirComentario = s.nextLine();
                                    if (incluirComentario.equalsIgnoreCase("si")) {
                                        System.out.print("      Introduzca el comentario que desea incluir a continuación: ");
                                        comentario = s.nextLine();

                                        if (pedido1c1 != null && idPedidoIntro.equalsIgnoreCase(pedido1c1.getId_pedido()))
                                            pedido1c1.setComentario(comentario);
                                        else if (pedido2c1 != null && idPedidoIntro.equalsIgnoreCase(pedido2c1.getId_pedido()))
                                            pedido2c1.setComentario(comentario);
                                        else if (pedido1c2 != null && idPedidoIntro.equalsIgnoreCase(pedido1c2.getId_pedido()))
                                            pedido1c2.setComentario(comentario);
                                        else if (pedido2c2 != null && idPedidoIntro.equalsIgnoreCase(pedido2c2.getId_pedido()))
                                            pedido2c2.setComentario(comentario);
                                        else System.out.println(" - Ha ocurrido un error -");
                                        Utils.mensajeDatoModificado();
                                    }

                                    //preguntamos por la fecha estimada
                                    System.out.print("  ¿Deseas cambiar la fecha estimada de este pedido? (SI/NO): ");
                                    cambiarFechaEstimada = s.nextLine();
                                    if (cambiarFechaEstimada.equalsIgnoreCase("si")) {
                                        System.out.print("      Introduzca la fecha estimada que desea incluir a continuación (DD-MM-YYYY): ");
                                        fechaIntro = s.nextLine();

                                        // Validar si la fecha tiene el formato adecuado
                                        if (fechaIntro.length() == 10 && fechaIntro.charAt(2) == '-' && fechaIntro.charAt(5) == '-') {
                                            // Extraer día, mes y año usando substring
                                            String diaStr = fechaIntro.substring(0, 2);
                                            String mesStr = fechaIntro.substring(3, 5);
                                            String anioStr = fechaIntro.substring(6, 10);

                                            // Convertir las partes a números
                                            if (Pedido.esNumero(diaStr) && Pedido.esNumero(mesStr) && Pedido.esNumero(anioStr)) {
                                                dia = Integer.parseInt(diaStr);
                                                mes = Integer.parseInt(mesStr);
                                                anio = Integer.parseInt(anioStr);

                                                // Validar que la fecha es válida
                                                if (esFechaValida(dia, mes, anio)) {
                                                    // Crear el objeto LocalDate con la fecha validada
                                                    fechaEstimadaIntro = LocalDate.of(anio, mes, dia);

                                                    // Asignar la fecha estimada al pedido correspondiente
                                                    if (pedido1c1 != null && idPedidoIntro.equalsIgnoreCase(pedido1c1.getId_pedido()))
                                                        pedido1c1.setFechaEstimada(fechaEstimadaIntro);
                                                    else if (pedido2c1 != null && idPedidoIntro.equalsIgnoreCase(pedido2c1.getId_pedido()))
                                                        pedido2c1.setFechaEstimada(fechaEstimadaIntro);
                                                    else if (pedido1c2 != null && idPedidoIntro.equalsIgnoreCase(pedido1c2.getId_pedido()))
                                                        pedido1c2.setFechaEstimada(fechaEstimadaIntro);
                                                    else if (pedido2c2 != null && idPedidoIntro.equalsIgnoreCase(pedido2c2.getId_pedido()))
                                                        pedido2c2.setFechaEstimada(fechaEstimadaIntro);
                                                    else System.out.println(" - Ha ocurrido un error -");

                                                    Utils.mensajeDatoModificado();
                                                } else
                                                    System.out.println("Fecha no válida. Asegúrese de que el día, mes y año son correctos.");
                                            } else
                                                System.out.println("Formato de fecha incorrecto. Asegúrese de usar el formato DD-MM-YYYY.");
                                        } else
                                            System.out.println("Formato de fecha incorrecto. Asegúrese de usar el formato DD-MM-YYYY.");
                                    }
                                    break;

                                case "3":
                                    //CONSULTA CATÁLOGO DE PRODUCTOS
                                    System.out.println(ProductoData.pintaProductos());
                                    Utils.pulsaParaContinuar();
                                    break;
                                    
                                case "4":
                                    //MODIFICAR UN PRODUCTO DEL CATÁLOGO
                                    do {
                                        System.out.println(ProductoData.pintaProductos());
                                        System.out.print("Elija el producto que desea cambiar (No: Para Salir): ");
                                        op3 = s.nextLine();
                                        switch (op3) {
                                            case "001":
                                                //LIBRETA
                                                Menus.pintaOpcionesCambio();
                                                System.out.print("Introduzca la opción que desea cambiar: ");
                                                op6 = s.nextLine();
                                                if (!op6.equalsIgnoreCase("4")) {
                                                    System.out.print("Introduzca el valor modificado: ");
                                                    datoModificado = s.nextLine();
                                                    if (!ProductoData.cambiaDatosProducto(ProductoData.libreta, op6, datoModificado))
                                                        System.out.println(" · No se ha podido cambiar el dato, vuélvalo a intentar · ");
                                                    else System.out.println(" · Dato cambiado correctamente · ");
                                                } else Utils.saliendo();
                                                break;

                                            case "002":
                                                //LÁPICES
                                                Menus.pintaOpcionesCambio();
                                                System.out.print("Introduzca la opción que desea cambiar: ");
                                                op6 = s.nextLine();
                                                if (!op6.equalsIgnoreCase("4")) {
                                                    System.out.print("Introduzca el valor modificado: ");
                                                    datoModificado = s.nextLine();
                                                    if (!ProductoData.cambiaDatosProducto(ProductoData.lapicesColores, op6, datoModificado))
                                                        System.out.println(" · No se ha podido cambiar el dato, vuélvalo a intentar · ");
                                                    else System.out.println(" · Dato cambiado correctamente · ");
                                                } else Utils.saliendo();
                                                break;

                                            case "003":
                                                //ROTULADORES
                                                Menus.pintaOpcionesCambio();
                                                System.out.print("Introduzca la opción que desea cambiar: ");
                                                op6 = s.nextLine();
                                                if (!op6.equalsIgnoreCase("4")) {
                                                    System.out.print("Introduzca el valor modificado: ");
                                                    datoModificado = s.nextLine();
                                                    if (!ProductoData.cambiaDatosProducto(ProductoData.rotuladores, op6, datoModificado))
                                                        System.out.println(" · No se ha podido cambiar el dato, vuélvalo a intentar · ");
                                                    else System.out.println(" · Dato cambiado correctamente · ");
                                                } else Utils.saliendo();
                                                break;

                                            case "004":
                                                //ESTUCHE
                                                Menus.pintaOpcionesCambio();
                                                System.out.print("Introduzca la opción que desea cambiar: ");
                                                op6 = s.nextLine();
                                                if (!op6.equalsIgnoreCase("4")) {
                                                    System.out.print("Introduzca el valor modificado: ");
                                                    datoModificado = s.nextLine();
                                                    if (!ProductoData.cambiaDatosProducto(ProductoData.estuche, op6, datoModificado))
                                                        System.out.println(" · No se ha podido cambiar el dato, vuélvalo a intentar · ");
                                                    else System.out.println(" · Dato cambiado correctamente · ");
                                                } else Utils.saliendo();
                                                break;

                                            case "005":
                                                //FOLIOS
                                                Menus.pintaOpcionesCambio();
                                                System.out.print("Introduzca la opción que desea cambiar: ");
                                                op6 = s.nextLine();
                                                if (!op6.equalsIgnoreCase("4")) {
                                                    System.out.print("Introduzca el valor modificado: ");
                                                    datoModificado = s.nextLine();
                                                    if (!ProductoData.cambiaDatosProducto(ProductoData.folios, op6, datoModificado))
                                                        System.out.println(" · No se ha podido cambiar el dato, vuélvalo a intentar · ");
                                                    else System.out.println(" · Dato cambiado correctamente · ");
                                                } else Utils.saliendo();
                                                break;

                                            case "006":
                                                //MOCHILA
                                                Menus.pintaOpcionesCambio();
                                                System.out.print("Introduzca la opción que desea cambiar: ");
                                                op6 = s.nextLine();
                                                if (!op6.equalsIgnoreCase("4")) {
                                                    System.out.print("Introduzca el valor modificado: ");
                                                    datoModificado = s.nextLine();
                                                    if (!ProductoData.cambiaDatosProducto(ProductoData.mochila, op6, datoModificado))
                                                        System.out.println(" · No se ha podido cambiar el dato, vuélvalo a intentar · ");
                                                    else System.out.println(" · Dato cambiado correctamente · ");
                                                } else Utils.saliendo();
                                                break;

                                            case "007":
                                                //LIBRO1
                                                Menus.pintaOpcionesCambio();
                                                System.out.print("Introduzca la opción que desea cambiar: ");
                                                op6 = s.nextLine();
                                                if (!op6.equalsIgnoreCase("4")) {
                                                    System.out.print("Introduzca el valor modificado: ");
                                                    datoModificado = s.nextLine();
                                                    if (!ProductoData.cambiaDatosProducto(ProductoData.libro1, op6, datoModificado))
                                                        System.out.println(" · No se ha podido cambiar el dato, vuélvalo a intentar · ");
                                                    else System.out.println(" · Dato cambiado correctamente · ");
                                                } else Utils.saliendo();
                                                break;

                                            case "008":
                                                //LIBRO2
                                                Menus.pintaOpcionesCambio();
                                                System.out.print("Introduzca la opción que desea cambiar: ");
                                                op6 = s.nextLine();
                                                if (!op6.equalsIgnoreCase("4")) {
                                                    System.out.print("Introduzca el valor modificado: ");
                                                    datoModificado = s.nextLine();
                                                    if (!ProductoData.cambiaDatosProducto(ProductoData.libro2, op6, datoModificado))
                                                        System.out.println(" · No se ha podido cambiar el dato, vuélvalo a intentar · ");
                                                    else System.out.println(" · Dato cambiado correctamente · ");
                                                } else Utils.saliendo();
                                                break;

                                            default:
                                                if (!op3.equalsIgnoreCase("no"))
                                                    System.out.println("  · Opción Introducida Incorrecta, vuelva a probar ·");
                                        }


                                    } while (!op3.equalsIgnoreCase("no"));
                                    break;
                                case "5":
                                    //VER MI PERFIL
                                    if (esTrabajador1) System.out.println(trabajador1.pintaTrabajador());
                                    else if (esTrabajador2) System.out.println(trabajador2.pintaTrabajador());
                                    else System.out.println(trabajador3.pintaTrabajador());
                                    Utils.pulsaParaContinuar();
                                    break;
                                case "6":
                                    //MODIFICAR MIS DATOS PERSONALES
                                    do {
                                        Menus.menuCambiaDatosTrabajador();
                                        System.out.print("Elija el dato que desea cambiar: ");
                                        op3 = s.nextLine();
                                        switch (op3) {
                                            case "1":
                                                //EMAIL
                                                do {
                                                    System.out.print("Introduzca el nuevo email: ");
                                                    email = s.nextLine();
                                                    if (Cliente.validarEmail(email)) {
                                                        if (esTrabajador1) trabajador1.setEmail(email);
                                                        else if (esTrabajador2) trabajador2.setEmail(email);
                                                        else trabajador3.setEmail(email);
                                                    }
                                                } while (!Cliente.validarEmail(email));
                                                Utils.mensajeDatoModificado();
                                                break;

                                            case "2":
                                                //CLAVE
                                                do {
                                                    System.out.print("Introduzca la nueva contraseña: ");
                                                    clave1 = s.nextLine();
                                                    System.out.print("Vuelva a introducir la nueva contraseña: ");
                                                    clave2 = s.nextLine();
                                                    if (Cliente.validaClave(clave1, clave2)) {
                                                        if (esTrabajador1) trabajador1.setClave(clave1);
                                                        else if (esTrabajador2) trabajador2.setClave(clave1);
                                                        else trabajador3.setClave(clave1);
                                                    } else
                                                        System.out.println(" · Las contraseñas no coinciden, vuelve a intentarlo · ");
                                                } while (!Cliente.validaClave(clave1, clave2));
                                                Utils.mensajeDatoModificado();
                                                break;

                                            case "3":
                                                //NOMBRE
                                                do {
                                                    System.out.print("Introduzca el nuevo nombre: ");
                                                    nombre = s.nextLine();
                                                    nombreModificado = nombre.substring(0, 1).toUpperCase() + nombre.substring(1).toLowerCase();
                                                    nombre = nombreModificado;
                                                    if (Cliente.validaNombre(nombre)) {
                                                        if (esTrabajador1) trabajador1.setNombre(nombre);
                                                        else if (esTrabajador2) trabajador2.setNombre(nombre);
                                                        else trabajador3.setNombre(nombre);
                                                    } else
                                                        System.out.println(" · No se ha podido modificar el nombre, inténtelo de nuevo ·");
                                                } while (!Cliente.validaNombre(nombre));
                                                Utils.mensajeDatoModificado();
                                                break;

                                            case "4":
                                                //DNI
                                                do {
                                                    System.out.print("Introduzca el nuevo DNI: ");
                                                    dni = s.nextLine();
                                                    if (Cliente.validaDNI(dni)) {
                                                        if (esTrabajador1) trabajador1.setDni(dni);
                                                        else if (esTrabajador2) trabajador2.setDni(dni);
                                                        else trabajador3.setDni(dni);
                                                    } else
                                                        System.out.println(" · No se ha podido modificar el DNI, inténtelo de nuevo ·");
                                                } while (!Cliente.validaDNI(dni));
                                                Utils.mensajeDatoModificado();
                                                break;

                                            case "5":
                                                //Salir del menu cambiar datos
                                                Utils.saliendo();
                                                break;

                                            default:
                                                System.out.println("  · Opción Introducida Incorrecta, vuelva a probar ·");
                                        }
                                    } while (!op3.equals("5"));
                                    break;
                                case "7":
                                    //CERRAR SESIÓN
                                    Utils.cerrandoSesion();
                                    break;
                                default:
                                    System.out.println(" · OPCIÓN INTRODUCIDA INCORRECTA · ");
                            }
                        } while (!op5.equals("7"));
                    }

                    //MOSTRAMOS EL MENÚ DE ADMINISTRADOR CON SUS OPCIONES:
                    if (esAdministrador) {
                        do {
                            Menus.menuAdministrador(administrador.getNombre(), Pedido.getContador());
                            System.out.print("Introduzca una opción: ");
                            op5 = s.nextLine();
                            switch (op5) {
                                case "1":
                                    //ASIGNAR UN PEDIDO A UN TRABAJADOR
                                    //enseñar lista de pedidos por asignar
                                    System.out.print(Pedido.pintaPedidosSinAsignar(cliente1, cliente2));
                                    System.out.print("Introduzca un pedido para asignar: ");
                                    opcionPedido = s.nextLine();
                                    //enseñar lista de trabajadores con el nº de pedidos que tienen asignados
                                    System.out.println(Trabajador.pintaTrabajadores(trabajador1, trabajador2, trabajador3));
                                    System.out.println("Introduzca un trabajador para asignarle el pedido: ");
                                    opcionTrabajador = s.nextLine();
                                    //llamamos al método para asignar:
                                    if (Pedido.asignaPedidosTrabajador(opcionPedido, opcionTrabajador, pedido1c1, pedido2c1, pedido1c2, pedido2c2, trabajador1, trabajador2, trabajador3))
                                        System.out.print(" · PEDIDO ASIGNADO CON ÉXITO · ");
                                    else System.out.print(" · NO SE HA PODIDO ASIGNAR EL PEDIDO ·");
                                    Utils.pulsaParaContinuar();
                                    break;
                                case "2":
                                    //MODIFICAR EL ESTADO DE UN PEDIDO
                                    System.out.print("Introduzca el id del pedido que quiere modificar: ");
                                    idPedidoIntro = s.nextLine();
                                    Menus.menuCambiaEstado();
                                    System.out.print("Introduzca el estado al que desea cambiarlo: ");
                                    estado = s.nextLine();
                                    switch (estado) {
                                        case "1":
                                            if (pedido1c1 != null && idPedidoIntro.equalsIgnoreCase(pedido1c1.getId_pedido()))
                                                pedido1c1.setEstado("En Preparación");
                                            else if (pedido2c1 != null && idPedidoIntro.equalsIgnoreCase(pedido2c1.getId_pedido()))
                                                pedido2c1.setEstado("En Preparación");
                                            else if (pedido1c2 != null && idPedidoIntro.equalsIgnoreCase(pedido1c2.getId_pedido()))
                                                pedido1c2.setEstado("En Preparación");
                                            else if (pedido2c2 != null && idPedidoIntro.equalsIgnoreCase(pedido2c2.getId_pedido()))
                                                pedido2c2.setEstado("En Preparación");
                                            else System.out.println(" - Ha ocurrido un error -");
                                            Utils.mensajeDatoModificado();
                                            break;
                                        case "2":
                                            if (pedido1c1 != null && idPedidoIntro.equalsIgnoreCase(pedido1c1.getId_pedido()))
                                                pedido1c1.setEstado("Enviado");
                                            else if (pedido2c1 != null && idPedidoIntro.equalsIgnoreCase(pedido2c1.getId_pedido()))
                                                pedido2c1.setEstado("Enviado");
                                            else if (pedido1c2 != null && idPedidoIntro.equalsIgnoreCase(pedido1c2.getId_pedido()))
                                                pedido1c2.setEstado("Enviado");
                                            else if (pedido2c2 != null && idPedidoIntro.equalsIgnoreCase(pedido2c2.getId_pedido()))
                                                pedido2c2.setEstado("Enviado");
                                            else System.out.println(" - Ha ocurrido un error -");
                                            Utils.mensajeDatoModificado();
                                            break;
                                        case "3":
                                            if (pedido1c1 != null && idPedidoIntro.equalsIgnoreCase(pedido1c1.getId_pedido()))
                                                pedido1c1.setEstado("Cancelado");
                                            else if (pedido2c1 != null && idPedidoIntro.equalsIgnoreCase(pedido2c1.getId_pedido()))
                                                pedido2c1.setEstado("Cancelado");
                                            else if (pedido1c2 != null && idPedidoIntro.equalsIgnoreCase(pedido1c2.getId_pedido()))
                                                pedido1c2.setEstado("Cancelado");
                                            else if (pedido2c2 != null && idPedidoIntro.equalsIgnoreCase(pedido2c2.getId_pedido()))
                                                pedido2c2.setEstado("Cancelado");
                                            else System.out.println(" - Ha ocurrido un error -");
                                            Utils.mensajeDatoModificado();
                                            break;
                                        case "4":
                                            if (pedido1c1 != null && idPedidoIntro.equalsIgnoreCase(pedido1c1.getId_pedido()))
                                                pedido1c1.setEstado("Recibido");
                                            else if (pedido2c1 != null && idPedidoIntro.equalsIgnoreCase(pedido2c1.getId_pedido()))
                                                pedido2c1.setEstado("Recibido");
                                            else if (pedido1c2 != null && idPedidoIntro.equalsIgnoreCase(pedido1c2.getId_pedido()))
                                                pedido1c2.setEstado("Recibido");
                                            else if (pedido2c2 != null && idPedidoIntro.equalsIgnoreCase(pedido2c2.getId_pedido()))
                                                pedido2c2.setEstado("Recibido");
                                            else System.out.println(" - Ha ocurrido un error -");
                                            Utils.mensajeDatoModificado();
                                            break;
                                        case "5":
                                            if (pedido1c1 != null && idPedidoIntro.equalsIgnoreCase(pedido1c1.getId_pedido()))
                                                pedido1c1.setEstado("Retrasado");
                                            else if (pedido2c1 != null && idPedidoIntro.equalsIgnoreCase(pedido2c1.getId_pedido()))
                                                pedido2c1.setEstado("Retrasado");
                                            else if (pedido1c2 != null && idPedidoIntro.equalsIgnoreCase(pedido1c2.getId_pedido()))
                                                pedido1c2.setEstado("Retrasado");
                                            else if (pedido2c2 != null && idPedidoIntro.equalsIgnoreCase(pedido2c2.getId_pedido()))
                                                pedido2c2.setEstado("Retrasado");
                                            else System.out.println(" - Ha ocurrido un error -");
                                            Utils.mensajeDatoModificado();
                                            break;
                                        case "6":
                                            Utils.saliendo();
                                            break;
                                        default:
                                            System.out.println(" · OPCIÓN INTRODUCIDA INCORRECTA ·");
                                    }
                                    break;

                                case "3":
                                    if (trabajador1 != null && trabajador2 != null && trabajador3 != null)
                                        System.out.println(" · NO HAY HUECO PARA DAR DE ALTA A MÁS TRABAJADORES · ");
                                    else {
                                        //DAMOS DE ALTA A UN TRABAJADOR
                                        System.out.println();
                                        System.out.println("""
                                                ╔═════════════════════════════════════════════════╗
                                                ║       FORMULARIO DE ALTA DE UN TRABAJADOR       ║
                                                ╚═════════════════════════════════════════════════╝
                                                """);

                                        //pedimos email y lo validamos
                                        boolean esValido = false;
                                        do {
                                            System.out.print("·Introduzca el email del trabajador: ");
                                            emailTrabajador = s.nextLine();
                                            if (Cliente.validarEmail(emailTrabajador)) esValido = true;
                                            else
                                                System.out.println("     · LO SIENTO, ESTE EMAIL NO ES VÁLIDO, VUELVA A INTENTARLO · ");
                                        } while (!esValido);

                                        //pedimos contraseña y la validamos
                                        do {
                                            System.out.print("·Introduzca la contraseña del trabajador: ");
                                            clave1Trabajador = s.nextLine();
                                            System.out.print("·Vuelva a introducir la contraseña: ");
                                            clave2Trabajador = s.nextLine();
                                            if (Cliente.validaClave(clave1Trabajador, clave2Trabajador))
                                                System.out.println("     · CONTRASEÑA ACEPTADA · ");
                                            else
                                                System.out.println("    · LAS CONTRASEÑAS NO COINCIDEN, VUELVA A INTENTARLO · ");
                                        } while (!Cliente.validaClave(clave1Trabajador, clave2Trabajador));


                                        //pedimos datos extras del trabajador
                                        //pedimos NOMBRE:
                                        esValido = false;
                                        while (!esValido) {
                                            System.out.print("·Introduzca el nombre del trabajador: ");
                                            nombreTrabajador = s.nextLine();
                                            nombreModificado = nombreTrabajador.substring(0, 1).toUpperCase() + nombreTrabajador.substring(1).toLowerCase();
                                            nombreTrabajador = nombreModificado;
                                            if (!Cliente.validaNombre(nombreTrabajador))
                                                System.out.println(" · NOMBRE INTRODUCIDO INCORRECTO, VUELVA A INTENTARLO ·");
                                            else esValido = true;
                                        }

                                        //pedimos el dni del trabajador y lo validamos:
                                        boolean idValido = false;
                                        while (!idValido) {//proceso de validación del ID
                                            System.out.print("·Introduzca el DNI del trabajador: ");
                                            dniTrabajador = s.nextLine();
                                            if (!Cliente.validaDNI(dniTrabajador))
                                                System.out.println(" · NÚMERO DE ID NO VÁLIDO, VUELVA A INTENTARLO ·");
                                            else
                                                idValido = true; //si el ID es correcto, el código sigue y no me muestra ningún mensaje
                                        }

                                        //GUARDAMOS LA INFORMACIÓN EN EL TRABAJADOR QUE ESTÉ A NULL:
                                        if (trabajador1 == null) {
                                            trabajador1 = new Trabajador(nombreTrabajador, clave1Trabajador, emailTrabajador, dniTrabajador);
                                        } else if (trabajador2 == null) {
                                            trabajador2 = new Trabajador(nombreTrabajador, clave1Trabajador, emailTrabajador, dniTrabajador);
                                        } else {
                                            trabajador3 = new Trabajador(nombreTrabajador, clave1Trabajador, emailTrabajador, dniTrabajador);
                                        }
                                    }

                                    break;

                                case "4":
                                    //VER TODOS LOS PEDIDOS
                                    if (pedido1c1 != null) {
                                        System.out.println(pedido1c1.pintaPedido(pedido1c1, cliente1));
                                        Utils.pulsaParaContinuar();
                                    }
                                    if (pedido2c1 != null) {
                                        System.out.println(pedido2c1.pintaPedido(pedido2c1, cliente1));
                                        Utils.pulsaParaContinuar();
                                    }
                                    if (pedido1c2 != null) {
                                        System.out.println(pedido1c2.pintaPedido(pedido1c2, cliente2));
                                        Utils.pulsaParaContinuar();
                                    }
                                    if (pedido2c2 != null) {
                                        System.out.println(pedido2c2.pintaPedido(pedido2c2, cliente2));
                                        Utils.pulsaParaContinuar();
                                    }
                                    if (pedido1c1 == null && pedido2c1 == null && pedido1c2 == null && pedido2c2 == null)
                                        System.out.println(" · NO HAY PEDIDOS PARA MOSTRAR · ");
                                    break;

                                case "5":
                                    //VER TODOS LOS CLIENTES
                                    if (cliente1 != null) {
                                        System.out.println(cliente1.pintaCliente());
                                        Utils.pulsaParaContinuar();
                                    }
                                    if (cliente2 != null) {
                                        System.out.println(cliente2.pintaCliente());
                                        Utils.pulsaParaContinuar();
                                    }
                                    if (cliente1 == null && cliente2 == null)
                                        System.out.println(" · NO HAY CLIENTES PARA MOSTRAR · ");
                                    break;

                                case "6":
                                    //VER TODOS LOS TRABAJADORES
                                    if (trabajador1 != null) {
                                        System.out.println(trabajador1.pintaTrabajador());
                                        Utils.pulsaParaContinuar();
                                    }
                                    if (trabajador2 != null) {
                                        System.out.println(trabajador2.pintaTrabajador());
                                        Utils.pulsaParaContinuar();
                                    }
                                    if (trabajador2 == null && trabajador1 == null)
                                        System.out.println(" · NO HAY TRABAJADORES PARA MOSTRAR · ");
                                    break;
                                case "7":
                                    //CERRAR SESIÓN
                                    Utils.cerrandoSesion();
                                    break;
                            }
                        } while (!op5.equals("7"));
                    }


                    //Registrarse:
                case "2":
                    if ((cliente1 != null && cliente2 != null) && !iniciaCliente) {
                        System.out.println("    - LO SENTIMOS, NO QUEDA ESPACIO PARA REGISTRARSE -\n");
                        Utils.pulsaParaContinuar();
                    } else if (!esTrabajador1 && !esTrabajador2 && !esTrabajador3 && !esAdministrador) {
                        if (!iniciaCliente) {
                            System.out.println("""
                                    ╔═══════════════════════════════════╗
                                    ║       FORMULARIO DE REGISTRO      ║
                                    ╚═══════════════════════════════════╝
                                    """);

                            //pedimos email y lo validamos
                            boolean esValido = false;
                            do {
                                System.out.print("·Introduzca su email: ");
                                email = s.nextLine();
                                if (Cliente.validarEmail(email)) esValido = true;
                                else
                                    System.out.println("\t · LO SIENTO, ESTE EMAIL NO ES VÁLIDO, VUELVA A INTENTARLO · ");
                            } while (!esValido);

                            //pedimos contraseña y la validamos
                            do {
                                System.out.print("·Introduzca su contraseña: ");
                                clave1 = s.nextLine();
                                System.out.print("·Vuelva a introducir su contraseña: ");
                                clave2 = s.nextLine();
                                if (Cliente.validaClave(clave1, clave2))
                                    System.out.println("\t · CONTRASEÑA ACEPTADA · ");
                                else System.out.println("\t · LAS CONTRASEÑAS NO COINCIDEN, VUELVA A INTENTARLO · ");
                            } while (!Cliente.validaClave(clave1, clave2));


                            //pedimos datos extras del cliente
                            //pedimos NOMBRE:
                            esValido = false;
                            while (!esValido) {
                                System.out.print("·Introduzca su nombre: ");
                                nombre = s.nextLine();
                                nombreModificado = nombre.substring(0, 1).toUpperCase() + nombre.substring(1).toLowerCase();
                                nombre = nombreModificado;
                                if (!Cliente.validaNombre(nombre))
                                    System.out.println("\t · NOMBRE INTRODUCIDO INCORRECTO, VUELVA A INTENTARLO ·");
                                else esValido = true;
                            }

                            //pedimos APELLIDO:
                            esValido = false;
                            while (!esValido) {
                                System.out.print("·Introduzca su apellido: ");
                                apellido = s.nextLine();
                                apellidoModificado = apellido.substring(0, 1).toUpperCase() + apellido.substring(1).toLowerCase();
                                apellido = apellidoModificado;
                                if (!Cliente.validaApellido(apellido))
                                    System.out.println("\t · APELLIDO INTRODUCIDO INCORRECTO, VUELVA A INTENTARLO ·");
                                else esValido = true;
                            }

                            //pedimos el dni del cliente y lo validamos:
                            boolean idValido = false;
                            while (!idValido) {//proceso de validación del ID
                                System.out.print("·Introduzca su dni: ");
                                dni = s.nextLine();
                                if (!Cliente.validaDNI(dni))
                                    System.out.println("\t · NÚMERO DE ID NO VÁLIDO, VUELVA A INTENTARLO ·");
                                else
                                    idValido = true; //si el ID es correcto, el código sigue y no me muestra ningún mensaje
                            }

                            //pedimos la dirección:
                            do {
                                System.out.print("·Introduzca su dirección: ");
                                direccion = s.nextLine();
                                direccionModificado = direccion.substring(0, 1).toUpperCase() + direccion.substring(1).toLowerCase();
                                direccion = direccionModificado;
                                if (Cliente.validaDireccion(direccion))
                                    System.out.println("\t · DIRECCIÓN NO VÁLIDA, VUELVA A INTENTARLO ·");
                            } while (Cliente.validaDireccion(direccion));

                            //pedimos localidad:
                            do {
                                System.out.print("·Introduzca su localidad: ");
                                localidad = s.nextLine();
                                localidadModificada = localidad.substring(0, 1).toUpperCase() + localidad.substring(1).toLowerCase();
                                localidad = localidadModificada;
                                if (Cliente.validaLocalidad(localidad))
                                    System.out.println("\t · LOCALIDAD NO VÁLIDA, VUELVA A INTENTARLO ·");
                            } while (Cliente.validaLocalidad(localidad));

                            //pedimos provincia:
                            do {
                                System.out.print("·Introduzca su provincia: ");
                                provincia = s.nextLine();
                                provinciaModificada = provincia.substring(0, 1).toUpperCase() + provincia.substring(1).toLowerCase();
                                provincia = provinciaModificada;
                                if (Cliente.validaProvincia(provincia))
                                    System.out.println("\t · PROVINCIA NO VÁLIDA, VUELVA A INTENTARLO ·");
                            } while (Cliente.validaProvincia(provincia));

                            //pedimos el teléfono:
                            do {
                                System.out.print("·Introduzca su teléfono: ");
                                telefono = s.nextLine();
                                if (!Cliente.validaTelefono(telefono))
                                    System.out.println("\t · TELÉFONO NO VÁLIDO, VUELVA A INTENTARLO ·");
                            } while (!Cliente.validaTelefono(telefono));


                            //GUARDAMOS LA INFORMACIÓN EN EL CLIENTE QUE ESTÉ A NULL:
                            if (cliente1 == null) {
                                cliente1 = new Cliente(email, clave1, dni, nombre, apellido, direccion, localidad, provincia, telefono);
                            } else {
                                cliente2 = new Cliente(email, clave1, dni, nombre, apellido, direccion, localidad, provincia, telefono);
                            }


                            //TODO QUITAR AL FINAL --> PRUEBAS DE TOSTRING
                            //System.out.println(cliente1);
                            //System.out.println(cliente1.pintaCliente());

                            Utils.pulsaParaContinuar();
                        }
                        iniciaCliente = false; //reseteo la variable para cuando inicia sesión un cliente.
                        //SI INICIAS SESIÓN SALTAS DIRECTAMENTE A ESTA PARTE:

                        do {
                            System.out.println((cliente2 == null || (cliente1.getEmail().equals(email) && cliente1.getClave().equals(clave)) ?
                                    "\n¡Bienvenido/a, " + cliente1.getNombre() + "!" :
                                    "\n¡Bienvenido/a, " + cliente2.getNombre() + "!"));
                            Menus.menuCliente();
                            System.out.print("Introduzca la opción deseada: ");
                            op2 = s.nextLine();
                            switch (op2) {
                                case "1":
                                    //CONSULTA CATALOGO DE PRODUCTOS
                                    System.out.println(ProductoData.pintaProductos());
                                    Utils.pulsaParaContinuar();
                                    break;

                                case "2":
                                    //REALIZA UN PEDIDO
                                    //comprobamos si los pedidos del cliente están vacíos para realizar uno nuevo
                                    if ((cliente2 == null || (cliente1.getEmail().equals(email) && cliente1.getClave().equals(clave)))) {
                                        if (cliente1.getPedido1() == null) {
                                            //crea el pedido sobre el pedido1
                                            pedido1c1 = new Pedido(cliente1);

                                            //se le muestra la lista de productos que hay
                                            do {
                                                System.out.println(ProductoData.pintaProductos());
                                                System.out.print("Elige un producto para añadir al pedido (NO: para finalizar el pedido): ");
                                                op4 = s.nextLine();
                                                switch (op4) {
                                                    case "001": //Incluir libreta
                                                        //comprueba si los productos están ocupados:
                                                        if (producto1pe1c1 != null && producto2pe1c1 != null && producto3pe1c1 != null)
                                                            System.out.println("     · NO PUEDES INCLUIR MÁS PRODUCTOS A TU PEDIDO · ");
                                                        else {
                                                            do {
                                                                cantidadValida = true;
                                                                System.out.print("Cuántas unidades desea comprar: ");
                                                                unidadesAComprar = Integer.parseInt(s.nextLine());  //TODO OJO!! PUEDE PETAR SI METES UNA LETRA, AVISADOS ESTÁIS
                                                                //comprueba si la cantidad que se desea comprar es posible por el stock del producto:
                                                                if ((ProductoData.libreta.getStock() - unidadesAComprar) < 0) {
                                                                    System.out.println("La cantidad introducida no es válida. Quedan " +
                                                                            ProductoData.libreta.getStock() + " unidades de este producto.");
                                                                    cantidadValida = false;
                                                                } else {
                                                                    //comprueba si el primer producto está vacío
                                                                    if (producto1pe1c1 == null) {
                                                                        producto1pe1c1 = new Producto(ProductoData.libreta);
                                                                        producto1pe1c1.setCantidad(unidadesAComprar);
                                                                        pedido1c1.setProducto1(producto1pe1c1);
                                                                        producto1pe1c1.restaStock(ProductoData.libreta, unidadesAComprar);
                                                                    }
                                                                    //comprueba si el segundo producto está vacío
                                                                    else if (producto2pe1c1 == null) {
                                                                        producto2pe1c1 = new Producto(ProductoData.libreta);
                                                                        producto2pe1c1.setCantidad(unidadesAComprar);
                                                                        pedido1c1.setProducto2(producto2pe1c1);
                                                                        producto2pe1c1.restaStock(ProductoData.libreta, unidadesAComprar);
                                                                    } else {
                                                                        //finalmente, lo asigna al tercer producto
                                                                        producto3pe1c1 = new Producto(ProductoData.libreta);
                                                                        producto3pe1c1.setCantidad(unidadesAComprar);
                                                                        pedido1c1.setProducto3(producto3pe1c1);
                                                                        producto3pe1c1.restaStock(ProductoData.libreta, unidadesAComprar);
                                                                    }
                                                                    //texto final para concluir la inclusión del producto al pedido:
                                                                    Utils.incluirAlPedido();
                                                                    System.out.println("    · PRODUCTO AÑADIDO EXITOSAMENTE ·");
                                                                }
                                                            } while (!cantidadValida);
                                                        }
                                                        break;

                                                    case "002": //Incluir lápices
                                                        //comprueba si los productos están ocupados:
                                                        if (producto1pe1c1 != null && producto2pe1c1 != null && producto3pe1c1 != null)
                                                            System.out.println("     · NO PUEDES INCLUIR MÁS PRODUCTOS A TU PEDIDO · ");
                                                        else {
                                                            do {
                                                                cantidadValida = true;
                                                                System.out.print("Cuántas unidades desea comprar: ");
                                                                unidadesAComprar = Integer.parseInt(s.nextLine());  //TODO OJO!! PUEDE PETAR SI METES UNA LETRA, AVISADOS ESTÁIS
                                                                //comprueba si la cantidad que se desea comprar es posible por el stock del producto:
                                                                if ((ProductoData.lapicesColores.getStock() - unidadesAComprar) < 0) {
                                                                    System.out.println("La cantidad introducida no es válida. Quedan " +
                                                                            ProductoData.lapicesColores.getStock() + " unidades de este producto.");
                                                                    cantidadValida = false;
                                                                } else {
                                                                    //comprueba si el primer producto está vacío
                                                                    if (producto1pe1c1 == null) {
                                                                        producto1pe1c1 = new Producto(ProductoData.lapicesColores);
                                                                        producto1pe1c1.setCantidad(unidadesAComprar);
                                                                        pedido1c1.setProducto1(producto1pe1c1);
                                                                        producto1pe1c1.restaStock(ProductoData.lapicesColores, unidadesAComprar);
                                                                    }
                                                                    //comprueba si el segundo producto está vacío
                                                                    else if (producto2pe1c1 == null) {
                                                                        producto2pe1c1 = new Producto(ProductoData.lapicesColores);
                                                                        producto2pe1c1.setCantidad(unidadesAComprar);
                                                                        pedido1c1.setProducto2(producto2pe1c1);
                                                                        producto2pe1c1.restaStock(ProductoData.lapicesColores, unidadesAComprar);
                                                                    } else {
                                                                        //finalmente, lo asigna al tercer producto
                                                                        producto3pe1c1 = new Producto(ProductoData.lapicesColores);
                                                                        producto3pe1c1.setCantidad(unidadesAComprar);
                                                                        pedido1c1.setProducto3(producto3pe1c1);
                                                                        producto3pe1c1.restaStock(ProductoData.lapicesColores, unidadesAComprar);
                                                                    }
                                                                    //texto final para concluir la inclusión del producto al pedido:
                                                                    Utils.incluirAlPedido();
                                                                    System.out.println("    · PRODUCTO AÑADIDO EXITOSAMENTE ·");
                                                                }

                                                            } while (!cantidadValida);
                                                        }
                                                        break;
                                                    case "003": //Incluir rotuladores
                                                        //comprueba si los productos están ocupados:
                                                        if (producto1pe1c1 != null && producto2pe1c1 != null && producto3pe1c1 != null)
                                                            System.out.println("     · NO PUEDES INCLUIR MÁS PRODUCTOS A TU PEDIDO · ");
                                                        else {
                                                            do {
                                                                cantidadValida = true;
                                                                System.out.print("Cuántas unidades desea comprar: ");
                                                                unidadesAComprar = Integer.parseInt(s.nextLine());  //TODO OJO!! PUEDE PETAR SI METES UNA LETRA, AVISADOS ESTÁIS
                                                                //comprueba si la cantidad que se desea comprar es posible por el stock del producto:
                                                                if ((ProductoData.rotuladores.getStock() - unidadesAComprar) < 0) {
                                                                    System.out.println("La cantidad introducida no es válida. Quedan " +
                                                                            ProductoData.rotuladores.getStock() + " unidades de este producto.");
                                                                    cantidadValida = false;
                                                                } else {
                                                                    //comprueba si el primer producto está vacío
                                                                    if (producto1pe1c1 == null) {
                                                                        producto1pe1c1 = new Producto(ProductoData.rotuladores);
                                                                        producto1pe1c1.setCantidad(unidadesAComprar);
                                                                        pedido1c1.setProducto1(producto1pe1c1);
                                                                        producto1pe1c1.restaStock(ProductoData.rotuladores, unidadesAComprar);
                                                                    }
                                                                    //comprueba si el segundo producto está vacío
                                                                    else if (producto2pe1c1 == null) {
                                                                        producto2pe1c1 = new Producto(ProductoData.rotuladores);
                                                                        producto2pe1c1.setCantidad(unidadesAComprar);
                                                                        pedido1c1.setProducto2(producto2pe1c1);
                                                                        producto2pe1c1.restaStock(ProductoData.rotuladores, unidadesAComprar);
                                                                    } else {
                                                                        //finalmente, lo asigna al tercer producto
                                                                        producto3pe1c1 = new Producto(ProductoData.rotuladores);
                                                                        producto3pe1c1.setCantidad(unidadesAComprar);
                                                                        pedido1c1.setProducto3(producto3pe1c1);
                                                                        producto3pe1c1.restaStock(ProductoData.rotuladores, unidadesAComprar);
                                                                    }
                                                                    //texto final para concluir la inclusión del producto al pedido:
                                                                    Utils.incluirAlPedido();
                                                                    System.out.println("    · PRODUCTO AÑADIDO EXITOSAMENTE ·");
                                                                }
                                                            } while (!cantidadValida);
                                                        }
                                                        break;
                                                    case "004": //Incluir estuche
                                                        //comprueba si los productos están ocupados:
                                                        if (producto1pe1c1 != null && producto2pe1c1 != null && producto3pe1c1 != null)
                                                            System.out.println("     · NO PUEDES INCLUIR MÁS PRODUCTOS A TU PEDIDO · ");
                                                        else {
                                                            do {
                                                                cantidadValida = true;
                                                                System.out.print("Cuántas unidades desea comprar: ");
                                                                unidadesAComprar = Integer.parseInt(s.nextLine());  //TODO OJO!! PUEDE PETAR SI METES UNA LETRA, AVISADOS ESTÁIS
                                                                //comprueba si la cantidad que se desea comprar es posible por el stock del producto:
                                                                if ((ProductoData.estuche.getStock() - unidadesAComprar) < 0) {
                                                                    System.out.println("La cantidad introducida no es válida. Quedan " +
                                                                            ProductoData.estuche.getStock() + " unidades de este producto.");
                                                                    cantidadValida = false;
                                                                } else {
                                                                    //comprueba si el primer producto está vacío
                                                                    if (producto1pe1c1 == null) {
                                                                        producto1pe1c1 = new Producto(ProductoData.estuche);
                                                                        producto1pe1c1.setCantidad(unidadesAComprar);
                                                                        pedido1c1.setProducto1(producto1pe1c1);
                                                                        producto1pe1c1.restaStock(ProductoData.estuche, unidadesAComprar);
                                                                    }
                                                                    //comprueba si el segundo producto está vacío
                                                                    else if (producto2pe1c1 == null) {
                                                                        producto2pe1c1 = new Producto(ProductoData.estuche);
                                                                        producto2pe1c1.setCantidad(unidadesAComprar);
                                                                        pedido1c1.setProducto2(producto2pe1c1);
                                                                        producto2pe1c1.restaStock(ProductoData.estuche, unidadesAComprar);
                                                                    } else {
                                                                        //finalmente, lo asigna al tercer producto
                                                                        producto3pe1c1 = new Producto(ProductoData.estuche);
                                                                        producto3pe1c1.setCantidad(unidadesAComprar);
                                                                        pedido1c1.setProducto3(producto3pe1c1);
                                                                        producto3pe1c1.restaStock(ProductoData.estuche, unidadesAComprar);
                                                                    }
                                                                    //texto final para concluir la inclusión del producto al pedido:
                                                                    Utils.incluirAlPedido();
                                                                    System.out.println("    · PRODUCTO AÑADIDO EXITOSAMENTE ·");
                                                                }
                                                            } while (!cantidadValida);
                                                        }
                                                        break;
                                                    case "005": //Incluir folios
                                                        //comprueba si los productos están ocupados:
                                                        if (producto1pe1c1 != null && producto2pe1c1 != null && producto3pe1c1 != null)
                                                            System.out.println("     · NO PUEDES INCLUIR MÁS PRODUCTOS A TU PEDIDO · ");
                                                        else {
                                                            do {
                                                                cantidadValida = true;
                                                                System.out.print("Cuántas unidades desea comprar: ");
                                                                unidadesAComprar = Integer.parseInt(s.nextLine());  //TODO OJO!! PUEDE PETAR SI METES UNA LETRA, AVISADOS ESTÁIS
                                                                //comprueba si la cantidad que se desea comprar es posible por el stock del producto:
                                                                if ((ProductoData.folios.getStock() - unidadesAComprar) < 0) {
                                                                    System.out.println("La cantidad introducida no es válida. Quedan " +
                                                                            ProductoData.folios.getStock() + " unidades de este producto.");
                                                                    cantidadValida = false;
                                                                } else {
                                                                    //comprueba si el primer producto está vacío
                                                                    if (producto1pe1c1 == null) {
                                                                        producto1pe1c1 = new Producto(ProductoData.folios);
                                                                        producto1pe1c1.setCantidad(unidadesAComprar);
                                                                        pedido1c1.setProducto1(producto1pe1c1);
                                                                        producto1pe1c1.restaStock(ProductoData.folios, unidadesAComprar);
                                                                    }
                                                                    //comprueba si el segundo producto está vacío
                                                                    else if (producto2pe1c1 == null) {
                                                                        producto2pe1c1 = new Producto(ProductoData.folios);
                                                                        producto2pe1c1.setCantidad(unidadesAComprar);
                                                                        pedido1c1.setProducto2(producto2pe1c1);
                                                                        producto2pe1c1.restaStock(ProductoData.folios, unidadesAComprar);
                                                                    } else {
                                                                        //finalmente, lo asigna al tercer producto
                                                                        producto3pe1c1 = new Producto(ProductoData.folios);
                                                                        producto3pe1c1.setCantidad(unidadesAComprar);
                                                                        pedido1c1.setProducto3(producto3pe1c1);
                                                                        producto3pe1c1.restaStock(ProductoData.folios, unidadesAComprar);
                                                                    }
                                                                    //texto final para concluir la inclusión del producto al pedido:
                                                                    Utils.incluirAlPedido();
                                                                    System.out.println("     · PRODUCTO AÑADIDO EXITOSAMENTE ·");
                                                                }
                                                            } while (!cantidadValida);
                                                        }
                                                        break;
                                                    case "006": //Incluir mochila
                                                        //comprueba si los productos están ocupados:
                                                        if (producto1pe1c1 != null && producto2pe1c1 != null && producto3pe1c1 != null)
                                                            System.out.println("     · NO PUEDES INCLUIR MÁS PRODUCTOS A TU PEDIDO · ");
                                                        else {
                                                            do {
                                                                cantidadValida = true;
                                                                System.out.print("Cuántas unidades desea comprar: ");
                                                                unidadesAComprar = Integer.parseInt(s.nextLine());  //TODO OJO!! PUEDE PETAR SI METES UNA LETRA, AVISADOS ESTÁIS
                                                                //comprueba si la cantidad que se desea comprar es posible por el stock del producto:
                                                                if ((ProductoData.mochila.getStock() - unidadesAComprar) < 0) {
                                                                    System.out.println("La cantidad introducida no es válida. Quedan " +
                                                                            ProductoData.mochila.getStock() + " unidades de este producto.");
                                                                    cantidadValida = false;
                                                                } else {
                                                                    //comprueba si el primer producto está vacío
                                                                    if (producto1pe1c1 == null) {
                                                                        producto1pe1c1 = new Producto(ProductoData.mochila);
                                                                        producto1pe1c1.setCantidad(unidadesAComprar);
                                                                        pedido1c1.setProducto1(producto1pe1c1);
                                                                        producto1pe1c1.restaStock(ProductoData.mochila, unidadesAComprar);
                                                                    }
                                                                    //comprueba si el segundo producto está vacío
                                                                    else if (producto2pe1c1 == null) {
                                                                        producto2pe1c1 = new Producto(ProductoData.mochila);
                                                                        producto2pe1c1.setCantidad(unidadesAComprar);
                                                                        pedido1c1.setProducto2(producto2pe1c1);
                                                                        producto2pe1c1.restaStock(ProductoData.mochila, unidadesAComprar);
                                                                    } else {
                                                                        //finalmente, lo asigna al tercer producto
                                                                        producto3pe1c1 = new Producto(ProductoData.mochila);
                                                                        producto3pe1c1.setCantidad(unidadesAComprar);
                                                                        pedido1c1.setProducto3(producto3pe1c1);
                                                                        producto3pe1c1.restaStock(ProductoData.mochila, unidadesAComprar);
                                                                    }
                                                                    //texto final para concluir la inclusión del producto al pedido:
                                                                    Utils.incluirAlPedido();
                                                                    System.out.println("     · PRODUCTO AÑADIDO EXITOSAMENTE ·");
                                                                }
                                                            } while (!cantidadValida);
                                                        }
                                                        break;
                                                    case "007": //Incluir libro1
                                                        //comprueba si los productos están ocupados:
                                                        if (producto1pe1c1 != null && producto2pe1c1 != null && producto3pe1c1 != null)
                                                            System.out.println("     · NO PUEDES INCLUIR MÁS PRODUCTOS A TU PEDIDO · ");
                                                        else {
                                                            do {
                                                                cantidadValida = true;
                                                                System.out.print("Cuántas unidades desea comprar: ");
                                                                unidadesAComprar = Integer.parseInt(s.nextLine());  //TODO OJO!! PUEDE PETAR SI METES UNA LETRA, AVISADOS ESTÁIS
                                                                //comprueba si la cantidad que se desea comprar es posible por el stock del producto:
                                                                if ((ProductoData.libro1.getStock() - unidadesAComprar) < 0) {
                                                                    System.out.println("La cantidad introducida no es válida. Quedan " +
                                                                            ProductoData.libro1.getStock() + " unidades de este producto.");
                                                                    cantidadValida = false;
                                                                } else {
                                                                    //comprueba si el primer producto está vacío
                                                                    if (producto1pe1c1 == null) {
                                                                        producto1pe1c1 = new Producto(ProductoData.libro1);
                                                                        producto1pe1c1.setCantidad(unidadesAComprar);
                                                                        pedido1c1.setProducto1(producto1pe1c1);
                                                                        producto1pe1c1.restaStock(ProductoData.libro1, unidadesAComprar);
                                                                    }
                                                                    //comprueba si el segundo producto está vacío
                                                                    else if (producto2pe1c1 == null) {
                                                                        producto2pe1c1 = new Producto(ProductoData.libro1);
                                                                        producto2pe1c1.setCantidad(unidadesAComprar);
                                                                        pedido1c1.setProducto2(producto2pe1c1);
                                                                        producto2pe1c1.restaStock(ProductoData.libro1, unidadesAComprar);
                                                                    } else {
                                                                        //finalmente, lo asigna al tercer producto
                                                                        producto3pe1c1 = new Producto(ProductoData.libro1);
                                                                        producto3pe1c1.setCantidad(unidadesAComprar);
                                                                        pedido1c1.setProducto3(producto3pe1c1);
                                                                        producto3pe1c1.restaStock(ProductoData.libro1, unidadesAComprar);
                                                                    }
                                                                    //texto final para concluir la inclusión del producto al pedido:
                                                                    Utils.incluirAlPedido();
                                                                    System.out.println("     · PRODUCTO AÑADIDO EXITOSAMENTE ·");
                                                                }
                                                            } while (!cantidadValida);
                                                        }
                                                        break;
                                                    case "008": //Incluir libro2
                                                        //comprueba si los productos están ocupados:
                                                        if (producto1pe1c1 != null && producto2pe1c1 != null && producto3pe1c1 != null)
                                                            System.out.println("     · NO PUEDES INCLUIR MÁS PRODUCTOS A TU PEDIDO · ");
                                                        else {
                                                            do {
                                                                cantidadValida = true;
                                                                System.out.print("Cuántas unidades desea comprar: ");
                                                                unidadesAComprar = Integer.parseInt(s.nextLine());  //TODO OJO!! PUEDE PETAR SI METES UNA LETRA, AVISADOS ESTÁIS
                                                                //comprueba si la cantidad que se desea comprar es posible por el stock del producto:
                                                                if ((ProductoData.libro2.getStock() - unidadesAComprar) < 0) {
                                                                    System.out.println("La cantidad introducida no es válida. Quedan " +
                                                                            ProductoData.libro2.getStock() + " unidades de este producto.");
                                                                    cantidadValida = false;
                                                                } else {
                                                                    //comprueba si el primer producto está vacío
                                                                    if (producto1pe1c1 == null) {
                                                                        producto1pe1c1 = new Producto(ProductoData.libro2);
                                                                        producto1pe1c1.setCantidad(unidadesAComprar);
                                                                        pedido1c1.setProducto1(producto1pe1c1);
                                                                        producto1pe1c1.restaStock(ProductoData.libro2, unidadesAComprar);
                                                                    }
                                                                    //comprueba si el segundo producto está vacío
                                                                    else if (producto2pe1c1 == null) {
                                                                        producto2pe1c1 = new Producto(ProductoData.libro2);
                                                                        producto2pe1c1.setCantidad(unidadesAComprar);
                                                                        pedido1c1.setProducto2(producto2pe1c1);
                                                                        producto2pe1c1.restaStock(ProductoData.libro2, unidadesAComprar);
                                                                    } else {
                                                                        //finalmente, lo asigna al tercer producto
                                                                        producto3pe1c1 = new Producto(ProductoData.libro2);
                                                                        producto3pe1c1.setCantidad(unidadesAComprar);
                                                                        pedido1c1.setProducto3(producto3pe1c1);
                                                                        producto3pe1c1.restaStock(ProductoData.libro2, unidadesAComprar);
                                                                    }
                                                                    //texto final para concluir la inclusión del producto al pedido:
                                                                    Utils.incluirAlPedido();
                                                                    System.out.println("    · PRODUCTO AÑADIDO EXITOSAMENTE ·");
                                                                }
                                                            } while (!cantidadValida);
                                                        }
                                                        break;
                                                    default:
                                                        if (!op4.equalsIgnoreCase("no"))
                                                            System.out.println("Opción introducida incorrecta. Pruebe de nuevo.");
                                                }
                                            } while (!op4.equalsIgnoreCase("no"));
                                            //seteamos el pedido creado al cliente correspondiente
                                            cliente1.setPedido1(pedido1c1);
                                        } else if (cliente1.getPedido2() == null) {
                                            //crea el pedido sobre el pedido1
                                            pedido2c1 = new Pedido(cliente1);
                                            //se le muestra la lista de productos que hay
                                            do {
                                                System.out.println(ProductoData.pintaProductos());
                                                System.out.print("Elige un producto para añadir al pedido (NO: para finalizar el pedido): ");
                                                op4 = s.nextLine();
                                                switch (op4) {
                                                    case "001": //Incluir libreta
                                                        //comprueba si los productos están ocupados:
                                                        if (producto1pe2c1 != null && producto2pe2c1 != null && producto3pe2c1 != null)
                                                            System.out.println("No puedes incluir más productos a tu Pedido.");
                                                        else {
                                                            do {
                                                                cantidadValida = true;
                                                                System.out.print("Cuántas unidades desea comprar: ");
                                                                unidadesAComprar = Integer.parseInt(s.nextLine());  //TODO OJO!! PUEDE PETAR SI METES UNA LETRA, AVISADOS ESTÁIS
                                                                //comprueba si la cantidad que se desea comprar es posible por el stock del producto:
                                                                if ((ProductoData.libreta.getStock() - unidadesAComprar) < 0) {
                                                                    System.out.println("La cantidad introducida no es válida. Quedan " +
                                                                            ProductoData.libreta.getStock() + " unidades de este producto.");
                                                                    cantidadValida = false;
                                                                } else {
                                                                    //comprueba si el primer producto está vacío
                                                                    if (producto1pe2c1 == null) {
                                                                        producto1pe2c1 = new Producto(ProductoData.libreta);
                                                                        producto1pe2c1.setCantidad(unidadesAComprar);
                                                                        pedido2c1.setProducto1(producto1pe2c1);
                                                                        producto1pe2c1.restaStock(ProductoData.libreta, unidadesAComprar);
                                                                    }
                                                                    //comprueba si el segundo producto está vacío
                                                                    else if (producto2pe2c1 == null) {
                                                                        producto2pe2c1 = new Producto(ProductoData.libreta);
                                                                        producto2pe2c1.setCantidad(unidadesAComprar);
                                                                        pedido2c1.setProducto2(producto2pe2c1);
                                                                        producto2pe2c1.restaStock(ProductoData.libreta, unidadesAComprar);
                                                                    } else {
                                                                        //finalmente, lo asigna al tercer producto
                                                                        producto3pe2c1 = new Producto(ProductoData.libreta);
                                                                        producto3pe2c1.setCantidad(unidadesAComprar);
                                                                        pedido2c1.setProducto3(producto3pe2c1);
                                                                        producto3pe2c1.restaStock(ProductoData.libreta, unidadesAComprar);
                                                                    }
                                                                    //texto final para concluir la inclusión del producto al pedido:
                                                                    Utils.incluirAlPedido();
                                                                    System.out.println("     · PRODUCTO AÑADIDO EXITOSAMENTE ·");
                                                                }
                                                            } while (!cantidadValida);
                                                        }
                                                        break;

                                                    case "002": //Incluir lápices
                                                        //comprueba si los productos están ocupados:
                                                        if (producto1pe2c1 != null && producto2pe2c1 != null && producto3pe2c1 != null)
                                                            System.out.println("     · NO PUEDES INCLUIR MÁS PRODUCTOS A TU PEDIDO · ");
                                                        else {
                                                            do {
                                                                cantidadValida = true;
                                                                System.out.print("Cuántas unidades desea comprar: ");
                                                                unidadesAComprar = Integer.parseInt(s.nextLine());  //TODO OJO!! PUEDE PETAR SI METES UNA LETRA, AVISADOS ESTÁIS
                                                                //comprueba si la cantidad que se desea comprar es posible por el stock del producto:
                                                                if ((ProductoData.lapicesColores.getStock() - unidadesAComprar) < 0) {
                                                                    System.out.println("La cantidad introducida no es válida. Quedan " +
                                                                            ProductoData.lapicesColores.getStock() + " unidades de este producto.");
                                                                    cantidadValida = false;
                                                                } else {
                                                                    //comprueba si el primer producto está vacío
                                                                    if (producto1pe2c1 == null) {
                                                                        producto1pe2c1 = new Producto(ProductoData.lapicesColores);
                                                                        producto1pe2c1.setCantidad(unidadesAComprar);
                                                                        pedido2c1.setProducto1(producto1pe2c1);
                                                                        producto1pe2c1.restaStock(ProductoData.lapicesColores, unidadesAComprar);
                                                                    }
                                                                    //comprueba si el segundo producto está vacío
                                                                    else if (producto2pe2c1 == null) {
                                                                        producto2pe2c1 = new Producto(ProductoData.lapicesColores);
                                                                        producto2pe2c1.setCantidad(unidadesAComprar);
                                                                        pedido2c1.setProducto2(producto2pe2c1);
                                                                        producto2pe2c1.restaStock(ProductoData.lapicesColores, unidadesAComprar);
                                                                    } else {
                                                                        //finalmente, lo asigna al tercer producto
                                                                        producto3pe2c1 = new Producto(ProductoData.lapicesColores);
                                                                        producto3pe2c1.setCantidad(unidadesAComprar);
                                                                        pedido2c1.setProducto3(producto3pe2c1);
                                                                        producto3pe2c1.restaStock(ProductoData.lapicesColores, unidadesAComprar);
                                                                    }
                                                                    //texto final para concluir la inclusión del producto al pedido:
                                                                    Utils.incluirAlPedido();
                                                                    System.out.println("    · PRODUCTO AÑADIDO EXITOSAMENTE ·");
                                                                }

                                                            } while (!cantidadValida);
                                                        }
                                                        break;
                                                    case "003": //Incluir rotuladores
                                                        //comprueba si los productos están ocupados:
                                                        if (producto1pe2c1 != null && producto2pe2c1 != null && producto3pe2c1 != null)
                                                            System.out.println("     · NO PUEDES INCLUIR MÁS PRODUCTOS A TU PEDIDO · ");
                                                        else {
                                                            do {
                                                                cantidadValida = true;
                                                                System.out.print("Cuántas unidades desea comprar: ");
                                                                unidadesAComprar = Integer.parseInt(s.nextLine());  //TODO OJO!! PUEDE PETAR SI METES UNA LETRA, AVISADOS ESTÁIS
                                                                //comprueba si la cantidad que se desea comprar es posible por el stock del producto:
                                                                if ((ProductoData.rotuladores.getStock() - unidadesAComprar) < 0) {
                                                                    System.out.println("La cantidad introducida no es válida. Quedan " +
                                                                            ProductoData.rotuladores.getStock() + " unidades de este producto.");
                                                                    cantidadValida = false;
                                                                } else {
                                                                    //comprueba si el primer producto está vacío
                                                                    if (producto1pe2c1 == null) {
                                                                        producto1pe2c1 = new Producto(ProductoData.rotuladores);
                                                                        producto1pe2c1.setCantidad(unidadesAComprar);
                                                                        pedido2c1.setProducto1(producto1pe2c1);
                                                                        producto1pe2c1.restaStock(ProductoData.rotuladores, unidadesAComprar);
                                                                    }
                                                                    //comprueba si el segundo producto está vacío
                                                                    else if (producto2pe2c1 == null) {
                                                                        producto2pe2c1 = new Producto(ProductoData.rotuladores);
                                                                        producto2pe2c1.setCantidad(unidadesAComprar);
                                                                        pedido2c1.setProducto2(producto2pe2c1);
                                                                        producto2pe2c1.restaStock(ProductoData.rotuladores, unidadesAComprar);
                                                                    } else {
                                                                        //finalmente, lo asigna al tercer producto
                                                                        producto3pe2c1 = new Producto(ProductoData.rotuladores);
                                                                        producto3pe2c1.setCantidad(unidadesAComprar);
                                                                        pedido2c1.setProducto3(producto3pe2c1);
                                                                        producto3pe2c1.restaStock(ProductoData.rotuladores, unidadesAComprar);
                                                                    }
                                                                    //texto final para concluir la inclusión del producto al pedido:
                                                                    Utils.incluirAlPedido();
                                                                    System.out.println("    · PRODUCTO AÑADIDO EXITOSAMENTE ·");
                                                                }
                                                            } while (!cantidadValida);
                                                        }
                                                        break;
                                                    case "004": //Incluir estuche
                                                        //comprueba si los productos están ocupados:
                                                        if (producto1pe2c1 != null && producto2pe2c1 != null && producto3pe2c1 != null)
                                                            System.out.println("     · NO PUEDES INCLUIR MÁS PRODUCTOS A TU PEDIDO · ");
                                                        else {
                                                            do {
                                                                cantidadValida = true;
                                                                System.out.print("Cuántas unidades desea comprar: ");
                                                                unidadesAComprar = Integer.parseInt(s.nextLine());  //TODO OJO!! PUEDE PETAR SI METES UNA LETRA, AVISADOS ESTÁIS
                                                                //comprueba si la cantidad que se desea comprar es posible por el stock del producto:
                                                                if ((ProductoData.estuche.getStock() - unidadesAComprar) < 0) {
                                                                    System.out.println("La cantidad introducida no es válida. Quedan " +
                                                                            ProductoData.estuche.getStock() + " unidades de este producto.");
                                                                    cantidadValida = false;
                                                                } else {
                                                                    //comprueba si el primer producto está vacío
                                                                    if (producto1pe2c1 == null) {
                                                                        producto1pe2c1 = new Producto(ProductoData.estuche);
                                                                        producto1pe2c1.setCantidad(unidadesAComprar);
                                                                        pedido2c1.setProducto1(producto1pe2c1);
                                                                        producto1pe2c1.restaStock(ProductoData.estuche, unidadesAComprar);
                                                                    }
                                                                    //comprueba si el segundo producto está vacío
                                                                    else if (producto2pe2c1 == null) {
                                                                        producto2pe2c1 = new Producto(ProductoData.estuche);
                                                                        producto2pe2c1.setCantidad(unidadesAComprar);
                                                                        pedido2c1.setProducto2(producto2pe2c1);
                                                                        producto2pe2c1.restaStock(ProductoData.estuche, unidadesAComprar);
                                                                    } else {
                                                                        //finalmente, lo asigna al tercer producto
                                                                        producto3pe2c1 = new Producto(ProductoData.estuche);
                                                                        producto3pe2c1.setCantidad(unidadesAComprar);
                                                                        pedido2c1.setProducto3(producto3pe2c1);
                                                                        producto3pe2c1.restaStock(ProductoData.estuche, unidadesAComprar);
                                                                    }
                                                                    //texto final para concluir la inclusión del producto al pedido:
                                                                    Utils.incluirAlPedido();
                                                                    System.out.println("    · PRODUCTO AÑADIDO EXITOSAMENTE ·");
                                                                }
                                                            } while (!cantidadValida);
                                                        }
                                                        break;
                                                    case "005": //Incluir folios
                                                        //comprueba si los productos están ocupados:
                                                        if (producto1pe2c1 != null && producto2pe2c1 != null && producto3pe2c1 != null)
                                                            System.out.println("     · NO PUEDES INCLUIR MÁS PRODUCTOS A TU PEDIDO · ");
                                                        else {
                                                            do {
                                                                cantidadValida = true;
                                                                System.out.print("Cuántas unidades desea comprar: ");
                                                                unidadesAComprar = Integer.parseInt(s.nextLine());  //TODO OJO!! PUEDE PETAR SI METES UNA LETRA, AVISADOS ESTÁIS
                                                                //comprueba si la cantidad que se desea comprar es posible por el stock del producto:
                                                                if ((ProductoData.folios.getStock() - unidadesAComprar) < 0) {
                                                                    System.out.println("La cantidad introducida no es válida. Quedan " +
                                                                            ProductoData.folios.getStock() + " unidades de este producto.");
                                                                    cantidadValida = false;
                                                                } else {
                                                                    //comprueba si el primer producto está vacío
                                                                    if (producto1pe2c1 == null) {
                                                                        producto1pe2c1 = new Producto(ProductoData.folios);
                                                                        producto1pe2c1.setCantidad(unidadesAComprar);
                                                                        pedido2c1.setProducto1(producto1pe2c1);
                                                                        producto1pe2c1.restaStock(ProductoData.folios, unidadesAComprar);
                                                                    }
                                                                    //comprueba si el segundo producto está vacío
                                                                    else if (producto2pe2c1 == null) {
                                                                        producto2pe2c1 = new Producto(ProductoData.folios);
                                                                        producto2pe2c1.setCantidad(unidadesAComprar);
                                                                        pedido2c1.setProducto2(producto2pe2c1);
                                                                        producto2pe2c1.restaStock(ProductoData.folios, unidadesAComprar);
                                                                    } else {
                                                                        //finalmente, lo asigna al tercer producto
                                                                        producto3pe2c1 = new Producto(ProductoData.folios);
                                                                        producto3pe2c1.setCantidad(unidadesAComprar);
                                                                        pedido2c1.setProducto3(producto3pe2c1);
                                                                        producto3pe2c1.restaStock(ProductoData.folios, unidadesAComprar);
                                                                    }
                                                                    //texto final para concluir la inclusión del producto al pedido:
                                                                    Utils.incluirAlPedido();
                                                                    System.out.println("    · PRODUCTO AÑADIDO EXITOSAMENTE ·");
                                                                }
                                                            } while (!cantidadValida);
                                                        }
                                                        break;
                                                    case "006": //Incluir mochila
                                                        //comprueba si los productos están ocupados:
                                                        if (producto1pe2c1 != null && producto2pe2c1 != null && producto3pe2c1 != null)
                                                            System.out.println("     · NO PUEDES INCLUIR MÁS PRODUCTOS A TU PEDIDO · ");
                                                        else {
                                                            do {
                                                                cantidadValida = true;
                                                                System.out.print("Cuántas unidades desea comprar: ");
                                                                unidadesAComprar = Integer.parseInt(s.nextLine());  //TODO OJO!! PUEDE PETAR SI METES UNA LETRA, AVISADOS ESTÁIS
                                                                //comprueba si la cantidad que se desea comprar es posible por el stock del producto:
                                                                if ((ProductoData.mochila.getStock() - unidadesAComprar) < 0) {
                                                                    System.out.println("La cantidad introducida no es válida. Quedan " +
                                                                            ProductoData.mochila.getStock() + " unidades de este producto.");
                                                                    cantidadValida = false;
                                                                } else {
                                                                    //comprueba si el primer producto está vacío
                                                                    if (producto1pe2c1 == null) {
                                                                        producto1pe2c1 = new Producto(ProductoData.mochila);
                                                                        producto1pe2c1.setCantidad(unidadesAComprar);
                                                                        pedido2c1.setProducto1(producto1pe2c1);
                                                                        producto1pe2c1.restaStock(ProductoData.mochila, unidadesAComprar);
                                                                    }
                                                                    //comprueba si el segundo producto está vacío
                                                                    else if (producto2pe2c1 == null) {
                                                                        producto2pe2c1 = new Producto(ProductoData.mochila);
                                                                        producto2pe2c1.setCantidad(unidadesAComprar);
                                                                        pedido2c1.setProducto2(producto2pe2c1);
                                                                        producto2pe2c1.restaStock(ProductoData.mochila, unidadesAComprar);
                                                                    } else {
                                                                        //finalmente, lo asigna al tercer producto
                                                                        producto3pe2c1 = new Producto(ProductoData.mochila);
                                                                        producto3pe2c1.setCantidad(unidadesAComprar);
                                                                        pedido2c1.setProducto3(producto3pe2c1);
                                                                        producto3pe2c1.restaStock(ProductoData.mochila, unidadesAComprar);
                                                                    }
                                                                    //texto final para concluir la inclusión del producto al pedido:
                                                                    Utils.incluirAlPedido();
                                                                    System.out.println("    · PRODUCTO AÑADIDO EXITOSAMENTE ·");
                                                                }
                                                            } while (!cantidadValida);
                                                        }
                                                        break;
                                                    case "007": //Incluir libro1
                                                        //comprueba si los productos están ocupados:
                                                        if (producto1pe2c1 != null && producto2pe2c1 != null && producto3pe2c1 != null)
                                                            System.out.println("     · NO PUEDES INCLUIR MÁS PRODUCTOS A TU PEDIDO · ");
                                                        else {
                                                            do {
                                                                cantidadValida = true;
                                                                System.out.print("Cuántas unidades desea comprar: ");
                                                                unidadesAComprar = Integer.parseInt(s.nextLine());  //TODO OJO!! PUEDE PETAR SI METES UNA LETRA, AVISADOS ESTÁIS
                                                                //comprueba si la cantidad que se desea comprar es posible por el stock del producto:
                                                                if ((ProductoData.libro1.getStock() - unidadesAComprar) < 0) {
                                                                    System.out.println("La cantidad introducida no es válida. Quedan " +
                                                                            ProductoData.libro1.getStock() + " unidades de este producto.");
                                                                    cantidadValida = false;
                                                                } else {
                                                                    //comprueba si el primer producto está vacío
                                                                    if (producto1pe2c1 == null) {
                                                                        producto1pe2c1 = new Producto(ProductoData.libro1);
                                                                        producto1pe2c1.setCantidad(unidadesAComprar);
                                                                        pedido2c1.setProducto1(producto1pe2c1);
                                                                        producto1pe2c1.restaStock(ProductoData.libro1, unidadesAComprar);
                                                                    }
                                                                    //comprueba si el segundo producto está vacío
                                                                    else if (producto2pe2c1 == null) {
                                                                        producto2pe2c1 = new Producto(ProductoData.libro1);
                                                                        producto2pe2c1.setCantidad(unidadesAComprar);
                                                                        pedido2c1.setProducto2(producto2pe2c1);
                                                                        producto2pe2c1.restaStock(ProductoData.libro1, unidadesAComprar);
                                                                    } else {
                                                                        //finalmente, lo asigna al tercer producto
                                                                        producto3pe2c1 = new Producto(ProductoData.libro1);
                                                                        producto3pe2c1.setCantidad(unidadesAComprar);
                                                                        pedido2c1.setProducto3(producto3pe2c1);
                                                                        producto3pe2c1.restaStock(ProductoData.libro1, unidadesAComprar);
                                                                    }
                                                                    //texto final para concluir la inclusión del producto al pedido:
                                                                    Utils.incluirAlPedido();
                                                                    System.out.println("     · PRODUCTO AÑADIDO EXITOSAMENTE ·");
                                                                }
                                                            } while (!cantidadValida);
                                                        }
                                                        break;
                                                    case "008": //Incluir libro2
                                                        //comprueba si los productos están ocupados:
                                                        if (producto1pe2c1 != null && producto2pe2c1 != null && producto3pe2c1 != null)
                                                            System.out.println("     · NO PUEDES INCLUIR MÁS PRODUCTOS A TU PEDIDO · ");
                                                        else {
                                                            do {
                                                                cantidadValida = true;
                                                                System.out.print("Cuántas unidades desea comprar: ");
                                                                unidadesAComprar = Integer.parseInt(s.nextLine());  //TODO OJO!! PUEDE PETAR SI METES UNA LETRA, AVISADOS ESTÁIS
                                                                //comprueba si la cantidad que se desea comprar es posible por el stock del producto:
                                                                if ((ProductoData.libro2.getStock() - unidadesAComprar) < 0) {
                                                                    System.out.println("La cantidad introducida no es válida. Quedan " +
                                                                            ProductoData.libro2.getStock() + " unidades de este producto.");
                                                                    cantidadValida = false;
                                                                } else {
                                                                    //comprueba si el primer producto está vacío
                                                                    if (producto1pe2c1 == null) {
                                                                        producto1pe2c1 = new Producto(ProductoData.libro2);
                                                                        producto1pe2c1.setCantidad(unidadesAComprar);
                                                                        pedido2c1.setProducto1(producto1pe2c1);
                                                                        producto1pe2c1.restaStock(ProductoData.libro2, unidadesAComprar);
                                                                    }
                                                                    //comprueba si el segundo producto está vacío
                                                                    else if (producto2pe2c1 == null) {
                                                                        producto2pe2c1 = new Producto(ProductoData.libro2);
                                                                        producto2pe2c1.setCantidad(unidadesAComprar);
                                                                        pedido2c1.setProducto2(producto2pe2c1);
                                                                        producto2pe2c1.restaStock(ProductoData.libro2, unidadesAComprar);
                                                                    } else {
                                                                        //finalmente, lo asigna al tercer producto
                                                                        producto3pe2c1 = new Producto(ProductoData.libro2);
                                                                        producto3pe2c1.setCantidad(unidadesAComprar);
                                                                        pedido2c1.setProducto3(producto3pe2c1);
                                                                        producto3pe2c1.restaStock(ProductoData.libro2, unidadesAComprar);
                                                                    }
                                                                    //texto final para concluir la inclusión del producto al pedido:
                                                                    Utils.incluirAlPedido();
                                                                    System.out.println("     · PRODUCTO AÑADIDO EXITOSAMENTE ·");
                                                                }
                                                            } while (!cantidadValida);
                                                        }
                                                        break;
                                                    default:
                                                        if (!op4.equalsIgnoreCase("no"))
                                                            System.out.println("Opción introducida incorrecta. Pruebe de nuevo.");
                                                }
                                            } while (!op4.equalsIgnoreCase("no"));
                                            //seteamos el pedido creado al cliente correspondiente
                                            cliente1.setPedido2(pedido2c1);
                                        } else
                                            System.out.println(" - NO PUEDES HACER MÁS PEDIDOS, CONSULTA EL ESTADO DE TUS PEDIDOS EN EL MENÚ ANTERIOR - ");

                                    } else {
                                        if (cliente2.getPedido1() == null) {
                                            //crea el pedido sobre el pedido1
                                            pedido1c2 = new Pedido(cliente2);

                                            //se le muestra la lista de productos que hay
                                            do {
                                                System.out.println(ProductoData.pintaProductos());
                                                System.out.print("Elige un producto para añadir al pedido (NO: para finalizar el pedido): ");
                                                op4 = s.nextLine();
                                                switch (op4) {
                                                    case "001": //Incluir libreta
                                                        //comprueba si los productos están ocupados:
                                                        if (producto1pe1c2 != null && producto2pe1c2 != null && producto3pe1c2 != null)
                                                            System.out.println("     · NO PUEDES INCLUIR MÁS PRODUCTOS A TU PEDIDO · ");
                                                        else {
                                                            do {
                                                                cantidadValida = true;
                                                                System.out.print("Cuántas unidades desea comprar: ");
                                                                unidadesAComprar = Integer.parseInt(s.nextLine());  //TODO OJO!! PUEDE PETAR SI METES UNA LETRA, AVISADOS ESTÁIS
                                                                //comprueba si la cantidad que se desea comprar es posible por el stock del producto:
                                                                if ((ProductoData.libreta.getStock() - unidadesAComprar) < 0) {
                                                                    System.out.println("La cantidad introducida no es válida. Quedan " +
                                                                            ProductoData.libreta.getStock() + " unidades de este producto.");
                                                                    cantidadValida = false;
                                                                } else {
                                                                    //comprueba si el primer producto está vacío
                                                                    if (producto1pe1c2 == null) {
                                                                        producto1pe1c2 = new Producto(ProductoData.libreta);
                                                                        producto1pe1c2.setCantidad(unidadesAComprar);
                                                                        pedido1c2.setProducto1(producto1pe1c2);
                                                                        producto1pe1c2.restaStock(ProductoData.libreta, unidadesAComprar);
                                                                    }
                                                                    //comprueba si el segundo producto está vacío
                                                                    else if (producto2pe1c2 == null) {
                                                                        producto2pe1c2 = new Producto(ProductoData.libreta);
                                                                        producto2pe1c2.setCantidad(unidadesAComprar);
                                                                        pedido1c2.setProducto2(producto2pe1c2);
                                                                        producto2pe1c2.restaStock(ProductoData.libreta, unidadesAComprar);
                                                                    } else {
                                                                        //finalmente, lo asigna al tercer producto
                                                                        producto3pe1c2 = new Producto(ProductoData.libreta);
                                                                        producto3pe1c2.setCantidad(unidadesAComprar);
                                                                        pedido1c2.setProducto3(producto3pe1c2);
                                                                        producto3pe1c2.restaStock(ProductoData.libreta, unidadesAComprar);
                                                                    }
                                                                    //texto final para concluir la inclusión del producto al pedido:
                                                                    Utils.incluirAlPedido();
                                                                    System.out.println("    · PRODUCTO AÑADIDO EXITOSAMENTE ·");
                                                                }
                                                            } while (!cantidadValida);
                                                        }
                                                        break;

                                                    case "002": //Incluir lápices
                                                        //comprueba si los productos están ocupados:
                                                        if (producto1pe1c2 != null && producto2pe1c2 != null && producto3pe1c2 != null)
                                                            System.out.println("     · NO PUEDES INCLUIR MÁS PRODUCTOS A TU PEDIDO · ");
                                                        else {
                                                            do {
                                                                cantidadValida = true;
                                                                System.out.print("Cuántas unidades desea comprar: ");
                                                                unidadesAComprar = Integer.parseInt(s.nextLine());  //TODO OJO!! PUEDE PETAR SI METES UNA LETRA, AVISADOS ESTÁIS
                                                                //comprueba si la cantidad que se desea comprar es posible por el stock del producto:
                                                                if ((ProductoData.lapicesColores.getStock() - unidadesAComprar) < 0) {
                                                                    System.out.println("La cantidad introducida no es válida. Quedan " +
                                                                            ProductoData.lapicesColores.getStock() + " unidades de este producto.");
                                                                    cantidadValida = false;
                                                                } else {
                                                                    //comprueba si el primer producto está vacío
                                                                    if (producto1pe1c2 == null) {
                                                                        producto1pe1c2 = new Producto(ProductoData.lapicesColores);
                                                                        producto1pe1c2.setCantidad(unidadesAComprar);
                                                                        pedido1c2.setProducto1(producto1pe1c2);
                                                                        producto1pe1c2.restaStock(ProductoData.lapicesColores, unidadesAComprar);
                                                                    }
                                                                    //comprueba si el segundo producto está vacío
                                                                    else if (producto2pe1c2 == null) {
                                                                        producto2pe1c2 = new Producto(ProductoData.lapicesColores);
                                                                        producto2pe1c2.setCantidad(unidadesAComprar);
                                                                        pedido1c2.setProducto2(producto2pe1c2);
                                                                        producto2pe1c2.restaStock(ProductoData.lapicesColores, unidadesAComprar);
                                                                    } else {
                                                                        //finalmente, lo asigna al tercer producto
                                                                        producto3pe1c2 = new Producto(ProductoData.lapicesColores);
                                                                        producto3pe1c2.setCantidad(unidadesAComprar);
                                                                        pedido1c2.setProducto3(producto3pe1c2);
                                                                        producto3pe1c2.restaStock(ProductoData.lapicesColores, unidadesAComprar);
                                                                    }
                                                                    //texto final para concluir la inclusión del producto al pedido:
                                                                    Utils.incluirAlPedido();
                                                                    System.out.println("    · PRODUCTO AÑADIDO EXITOSAMENTE ·");
                                                                }

                                                            } while (!cantidadValida);
                                                        }
                                                        break;
                                                    case "003": //Incluir rotuladores
                                                        //comprueba si los productos están ocupados:
                                                        if (producto1pe1c2 != null && producto2pe1c2 != null && producto3pe1c2 != null)
                                                            System.out.println("     · NO PUEDES INCLUIR MÁS PRODUCTOS A TU PEDIDO · ");
                                                        else {
                                                            do {
                                                                cantidadValida = true;
                                                                System.out.print("Cuántas unidades desea comprar: ");
                                                                unidadesAComprar = Integer.parseInt(s.nextLine());  //TODO OJO!! PUEDE PETAR SI METES UNA LETRA, AVISADOS ESTÁIS
                                                                //comprueba si la cantidad que se desea comprar es posible por el stock del producto:
                                                                if ((ProductoData.rotuladores.getStock() - unidadesAComprar) < 0) {
                                                                    System.out.println("La cantidad introducida no es válida. Quedan " +
                                                                            ProductoData.rotuladores.getStock() + " unidades de este producto.");
                                                                    cantidadValida = false;
                                                                } else {
                                                                    //comprueba si el primer producto está vacío
                                                                    if (producto1pe1c2 == null) {
                                                                        producto1pe1c2 = new Producto(ProductoData.rotuladores);
                                                                        producto1pe1c2.setCantidad(unidadesAComprar);
                                                                        pedido1c2.setProducto1(producto1pe1c2);
                                                                        producto1pe1c2.restaStock(ProductoData.rotuladores, unidadesAComprar);
                                                                    }
                                                                    //comprueba si el segundo producto está vacío
                                                                    else if (producto2pe1c2 == null) {
                                                                        producto2pe1c2 = new Producto(ProductoData.rotuladores);
                                                                        producto2pe1c2.setCantidad(unidadesAComprar);
                                                                        pedido1c2.setProducto2(producto2pe1c2);
                                                                        producto2pe1c2.restaStock(ProductoData.rotuladores, unidadesAComprar);
                                                                    } else {
                                                                        //finalmente, lo asigna al tercer producto
                                                                        producto3pe1c2 = new Producto(ProductoData.rotuladores);
                                                                        producto3pe1c2.setCantidad(unidadesAComprar);
                                                                        pedido1c2.setProducto3(producto3pe1c2);
                                                                        producto3pe1c2.restaStock(ProductoData.rotuladores, unidadesAComprar);
                                                                    }
                                                                    //texto final para concluir la inclusión del producto al pedido:
                                                                    Utils.incluirAlPedido();
                                                                    System.out.println("    · PRODUCTO AÑADIDO EXITOSAMENTE ·");
                                                                }
                                                            } while (!cantidadValida);
                                                        }
                                                        break;
                                                    case "004": //Incluir estuche
                                                        //comprueba si los productos están ocupados:
                                                        if (producto1pe1c2 != null && producto2pe1c2 != null && producto3pe1c2 != null)
                                                            System.out.println("     · NO PUEDES INCLUIR MÁS PRODUCTOS A TU PEDIDO · ");
                                                        else {
                                                            do {
                                                                cantidadValida = true;
                                                                System.out.print("Cuántas unidades desea comprar: ");
                                                                unidadesAComprar = Integer.parseInt(s.nextLine());  //TODO OJO!! PUEDE PETAR SI METES UNA LETRA, AVISADOS ESTÁIS
                                                                //comprueba si la cantidad que se desea comprar es posible por el stock del producto:
                                                                if ((ProductoData.estuche.getStock() - unidadesAComprar) < 0) {
                                                                    System.out.println("La cantidad introducida no es válida. Quedan " +
                                                                            ProductoData.estuche.getStock() + " unidades de este producto.");
                                                                    cantidadValida = false;
                                                                } else {
                                                                    //comprueba si el primer producto está vacío
                                                                    if (producto1pe1c2 == null) {
                                                                        producto1pe1c2 = new Producto(ProductoData.estuche);
                                                                        producto1pe1c2.setCantidad(unidadesAComprar);
                                                                        pedido1c2.setProducto1(producto1pe1c2);
                                                                        producto1pe1c2.restaStock(ProductoData.estuche, unidadesAComprar);
                                                                    }
                                                                    //comprueba si el segundo producto está vacío
                                                                    else if (producto2pe1c2 == null) {
                                                                        producto2pe1c2 = new Producto(ProductoData.estuche);
                                                                        producto2pe1c2.setCantidad(unidadesAComprar);
                                                                        pedido1c2.setProducto2(producto2pe1c2);
                                                                        producto2pe1c2.restaStock(ProductoData.estuche, unidadesAComprar);
                                                                    } else {
                                                                        //finalmente, lo asigna al tercer producto
                                                                        producto3pe1c2 = new Producto(ProductoData.estuche);
                                                                        producto3pe1c2.setCantidad(unidadesAComprar);
                                                                        pedido1c2.setProducto3(producto3pe1c2);
                                                                        producto3pe1c2.restaStock(ProductoData.estuche, unidadesAComprar);
                                                                    }
                                                                    //texto final para concluir la inclusión del producto al pedido:
                                                                    Utils.incluirAlPedido();
                                                                    System.out.println(" · PRODUCTO AÑADIDO EXITOSAMENTE ·");
                                                                }
                                                            } while (!cantidadValida);
                                                        }
                                                        break;
                                                    case "005": //Incluir folios
                                                        //comprueba si los productos están ocupados:
                                                        if (producto1pe1c2 != null && producto2pe1c2 != null && producto3pe1c2 != null)
                                                            System.out.println("No puedes incluir más productos a tu Pedido.");
                                                        else {
                                                            do {
                                                                cantidadValida = true;
                                                                System.out.print("Cuántas unidades desea comprar: ");
                                                                unidadesAComprar = Integer.parseInt(s.nextLine());  //TODO OJO!! PUEDE PETAR SI METES UNA LETRA, AVISADOS ESTÁIS
                                                                //comprueba si la cantidad que se desea comprar es posible por el stock del producto:
                                                                if ((ProductoData.folios.getStock() - unidadesAComprar) < 0) {
                                                                    System.out.println("La cantidad introducida no es válida. Quedan " +
                                                                            ProductoData.folios.getStock() + " unidades de este producto.");
                                                                    cantidadValida = false;
                                                                } else {
                                                                    //comprueba si el primer producto está vacío
                                                                    if (producto1pe1c2 == null) {
                                                                        producto1pe1c2 = new Producto(ProductoData.folios);
                                                                        producto1pe1c2.setCantidad(unidadesAComprar);
                                                                        pedido1c2.setProducto1(producto1pe1c2);
                                                                        producto1pe1c2.restaStock(ProductoData.folios, unidadesAComprar);
                                                                    }
                                                                    //comprueba si el segundo producto está vacío
                                                                    else if (producto2pe1c2 == null) {
                                                                        producto2pe1c2 = new Producto(ProductoData.folios);
                                                                        producto2pe1c2.setCantidad(unidadesAComprar);
                                                                        pedido1c2.setProducto2(producto2pe1c2);
                                                                        producto2pe1c2.restaStock(ProductoData.folios, unidadesAComprar);
                                                                    } else {
                                                                        //finalmente, lo asigna al tercer producto
                                                                        producto3pe1c2 = new Producto(ProductoData.folios);
                                                                        producto3pe1c2.setCantidad(unidadesAComprar);
                                                                        pedido1c2.setProducto3(producto3pe1c2);
                                                                        producto3pe1c2.restaStock(ProductoData.folios, unidadesAComprar);
                                                                    }
                                                                    //texto final para concluir la inclusión del producto al pedido:
                                                                    Utils.incluirAlPedido();
                                                                    System.out.println("    · PRODUCTO AÑADIDO EXITOSAMENTE ·");
                                                                }
                                                            } while (!cantidadValida);
                                                        }
                                                        break;
                                                    case "006": //Incluir mochila
                                                        //comprueba si los productos están ocupados:
                                                        if (producto1pe1c2 != null && producto2pe1c2 != null && producto3pe1c2 != null)
                                                            System.out.println("     · NO PUEDES INCLUIR MÁS PRODUCTOS A TU PEDIDO · ");
                                                        else {
                                                            do {
                                                                cantidadValida = true;
                                                                System.out.print("Cuántas unidades desea comprar: ");
                                                                unidadesAComprar = Integer.parseInt(s.nextLine());  //TODO OJO!! PUEDE PETAR SI METES UNA LETRA, AVISADOS ESTÁIS
                                                                //comprueba si la cantidad que se desea comprar es posible por el stock del producto:
                                                                if ((ProductoData.mochila.getStock() - unidadesAComprar) < 0) {
                                                                    System.out.println("La cantidad introducida no es válida. Quedan " +
                                                                            ProductoData.mochila.getStock() + " unidades de este producto.");
                                                                    cantidadValida = false;
                                                                } else {
                                                                    //comprueba si el primer producto está vacío
                                                                    if (producto1pe1c2 == null) {
                                                                        producto1pe1c2 = new Producto(ProductoData.mochila);
                                                                        producto1pe1c2.setCantidad(unidadesAComprar);
                                                                        pedido1c2.setProducto1(producto1pe1c2);
                                                                        producto1pe1c2.restaStock(ProductoData.mochila, unidadesAComprar);
                                                                    }
                                                                    //comprueba si el segundo producto está vacío
                                                                    else if (producto2pe1c2 == null) {
                                                                        producto2pe1c2 = new Producto(ProductoData.mochila);
                                                                        producto2pe1c2.setCantidad(unidadesAComprar);
                                                                        pedido1c2.setProducto2(producto2pe1c2);
                                                                        producto2pe1c2.restaStock(ProductoData.mochila, unidadesAComprar);
                                                                    } else {
                                                                        //finalmente, lo asigna al tercer producto
                                                                        producto3pe1c2 = new Producto(ProductoData.mochila);
                                                                        producto3pe1c2.setCantidad(unidadesAComprar);
                                                                        pedido1c2.setProducto3(producto3pe1c2);
                                                                        producto3pe1c2.restaStock(ProductoData.mochila, unidadesAComprar);
                                                                    }
                                                                    //texto final para concluir la inclusión del producto al pedido:
                                                                    Utils.incluirAlPedido();
                                                                    System.out.println(" · PRODUCTO AÑADIDO EXITOSAMENTE ·");
                                                                }
                                                            } while (!cantidadValida);
                                                        }
                                                        break;
                                                    case "007": //Incluir libro1
                                                        //comprueba si los productos están ocupados:
                                                        if (producto1pe1c2 != null && producto2pe1c2 != null && producto3pe1c2 != null)
                                                            System.out.println("     · NO PUEDES INCLUIR MÁS PRODUCTOS A TU PEDIDO · ");
                                                        else {
                                                            do {
                                                                cantidadValida = true;
                                                                System.out.print("Cuántas unidades desea comprar: ");
                                                                unidadesAComprar = Integer.parseInt(s.nextLine());  //TODO OJO!! PUEDE PETAR SI METES UNA LETRA, AVISADOS ESTÁIS
                                                                //comprueba si la cantidad que se desea comprar es posible por el stock del producto:
                                                                if ((ProductoData.libro1.getStock() - unidadesAComprar) < 0) {
                                                                    System.out.println("La cantidad introducida no es válida. Quedan " +
                                                                            ProductoData.libro1.getStock() + " unidades de este producto.");
                                                                    cantidadValida = false;
                                                                } else {
                                                                    //comprueba si el primer producto está vacío
                                                                    if (producto1pe1c2 == null) {
                                                                        producto1pe1c2 = new Producto(ProductoData.libro1);
                                                                        producto1pe1c2.setCantidad(unidadesAComprar);
                                                                        pedido1c2.setProducto1(producto1pe1c2);
                                                                        producto1pe1c2.restaStock(ProductoData.libro1, unidadesAComprar);
                                                                    }
                                                                    //comprueba si el segundo producto está vacío
                                                                    else if (producto2pe1c2 == null) {
                                                                        producto2pe1c2 = new Producto(ProductoData.libro1);
                                                                        producto2pe1c2.setCantidad(unidadesAComprar);
                                                                        pedido1c2.setProducto2(producto2pe1c2);
                                                                        producto2pe1c2.restaStock(ProductoData.libro1, unidadesAComprar);
                                                                    } else {
                                                                        //finalmente, lo asigna al tercer producto
                                                                        producto3pe1c2 = new Producto(ProductoData.libro1);
                                                                        producto3pe1c2.setCantidad(unidadesAComprar);
                                                                        pedido1c2.setProducto3(producto3pe1c2);
                                                                        producto3pe1c2.restaStock(ProductoData.libro1, unidadesAComprar);
                                                                    }
                                                                    //texto final para concluir la inclusión del producto al pedido:
                                                                    Utils.incluirAlPedido();
                                                                    System.out.println("     · PRODUCTO AÑADIDO EXITOSAMENTE ·");
                                                                }
                                                            } while (!cantidadValida);
                                                        }
                                                        break;
                                                    case "008": //Incluir libro2
                                                        //comprueba si los productos están ocupados:
                                                        if (producto1pe1c2 != null && producto2pe1c2 != null && producto3pe1c2 != null)
                                                            System.out.println("     · NO PUEDES INCLUIR MÁS PRODUCTOS A TU PEDIDO · ");
                                                        else {
                                                            do {
                                                                cantidadValida = true;
                                                                System.out.print("Cuántas unidades desea comprar: ");
                                                                unidadesAComprar = Integer.parseInt(s.nextLine());  //TODO OJO!! PUEDE PETAR SI METES UNA LETRA, AVISADOS ESTÁIS
                                                                //comprueba si la cantidad que se desea comprar es posible por el stock del producto:
                                                                if ((ProductoData.libro2.getStock() - unidadesAComprar) < 0) {
                                                                    System.out.println("La cantidad introducida no es válida. Quedan " +
                                                                            ProductoData.libro2.getStock() + " unidades de este producto.");
                                                                    cantidadValida = false;
                                                                } else {
                                                                    //comprueba si el primer producto está vacío
                                                                    if (producto1pe1c2 == null) {
                                                                        producto1pe1c2 = new Producto(ProductoData.libro2);
                                                                        producto1pe1c2.setCantidad(unidadesAComprar);
                                                                        pedido1c2.setProducto1(producto1pe1c2);
                                                                        producto1pe1c2.restaStock(ProductoData.libro2, unidadesAComprar);
                                                                    }
                                                                    //comprueba si el segundo producto está vacío
                                                                    else if (producto2pe1c2 == null) {
                                                                        producto2pe1c2 = new Producto(ProductoData.libro2);
                                                                        producto2pe1c2.setCantidad(unidadesAComprar);
                                                                        pedido1c2.setProducto2(producto2pe1c2);
                                                                        producto2pe1c2.restaStock(ProductoData.libro2, unidadesAComprar);
                                                                    } else {
                                                                        //finalmente, lo asigna al tercer producto
                                                                        producto3pe1c2 = new Producto(ProductoData.libro2);
                                                                        producto3pe1c2.setCantidad(unidadesAComprar);
                                                                        pedido1c2.setProducto3(producto3pe1c2);
                                                                        producto3pe1c2.restaStock(ProductoData.libro2, unidadesAComprar);
                                                                    }
                                                                    //texto final para concluir la inclusión del producto al pedido:
                                                                    Utils.incluirAlPedido();
                                                                    System.out.println("    · PRODUCTO AÑADIDO EXITOSAMENTE ·");
                                                                }
                                                            } while (!cantidadValida);
                                                        }
                                                        break;
                                                    default:
                                                        if (!op4.equalsIgnoreCase("no"))
                                                            System.out.println("Opción introducida incorrecta. Pruebe de nuevo.");
                                                }
                                            } while (!op4.equalsIgnoreCase("no"));
                                            //seteamos el pedido creado al cliente correspondiente
                                            cliente2.setPedido1(pedido1c2);
                                        } else if (cliente2.getPedido2() == null) {
                                            //crea el pedido sobre el pedido1
                                            pedido2c2 = new Pedido(cliente2);
                                            //se le muestra la lista de productos que hay
                                            do {
                                                System.out.println(ProductoData.pintaProductos());
                                                System.out.print("Elige un producto para añadir al pedido (NO: para finalizar el pedido): ");
                                                op4 = s.nextLine();
                                                switch (op4) {
                                                    case "001": //Incluir libreta
                                                        //comprueba si los productos están ocupados:
                                                        if (producto1pe2c2 != null && producto2pe2c2 != null && producto3pe2c2 != null)
                                                            System.out.println("     · NO PUEDES INCLUIR MÁS PRODUCTOS A TU PEDIDO · ");
                                                        else {
                                                            do {
                                                                cantidadValida = true;
                                                                System.out.print("Cuántas unidades desea comprar: ");
                                                                unidadesAComprar = Integer.parseInt(s.nextLine());  //TODO OJO!! PUEDE PETAR SI METES UNA LETRA, AVISADOS ESTÁIS
                                                                //comprueba si la cantidad que se desea comprar es posible por el stock del producto:
                                                                if ((ProductoData.libreta.getStock() - unidadesAComprar) < 0) {
                                                                    System.out.println("La cantidad introducida no es válida. Quedan " +
                                                                            ProductoData.libreta.getStock() + " unidades de este producto.");
                                                                    cantidadValida = false;
                                                                } else {
                                                                    //comprueba si el primer producto está vacío
                                                                    if (producto1pe2c2 == null) {
                                                                        producto1pe2c2 = new Producto(ProductoData.libreta);
                                                                        producto1pe2c2.setCantidad(unidadesAComprar);
                                                                        pedido2c2.setProducto1(producto1pe2c2);
                                                                        producto1pe2c2.restaStock(ProductoData.libreta, unidadesAComprar);
                                                                    }
                                                                    //comprueba si el segundo producto está vacío
                                                                    else if (producto2pe2c2 == null) {
                                                                        producto2pe2c2 = new Producto(ProductoData.libreta);
                                                                        producto2pe2c2.setCantidad(unidadesAComprar);
                                                                        pedido2c2.setProducto2(producto2pe2c2);
                                                                        producto2pe2c2.restaStock(ProductoData.libreta, unidadesAComprar);
                                                                    } else {
                                                                        //finalmente, lo asigna al tercer producto
                                                                        producto3pe2c2 = new Producto(ProductoData.libreta);
                                                                        producto3pe2c2.setCantidad(unidadesAComprar);
                                                                        pedido2c2.setProducto3(producto3pe2c2);
                                                                        producto3pe2c2.restaStock(ProductoData.libreta, unidadesAComprar);
                                                                    }
                                                                    //texto final para concluir la inclusión del producto al pedido:
                                                                    Utils.incluirAlPedido();
                                                                    System.out.println("    · PRODUCTO AÑADIDO EXITOSAMENTE ·");
                                                                }
                                                            } while (!cantidadValida);
                                                        }
                                                        break;

                                                    case "002": //Incluir lápices
                                                        //comprueba si los productos están ocupados:
                                                        if (producto1pe2c2 != null && producto2pe2c2 != null && producto3pe2c2 != null)
                                                            System.out.println("     · NO PUEDES INCLUIR MÁS PRODUCTOS A TU PEDIDO · ");
                                                        else {
                                                            do {
                                                                cantidadValida = true;
                                                                System.out.print("Cuántas unidades desea comprar: ");
                                                                unidadesAComprar = Integer.parseInt(s.nextLine());  //TODO OJO!! PUEDE PETAR SI METES UNA LETRA, AVISADOS ESTÁIS
                                                                //comprueba si la cantidad que se desea comprar es posible por el stock del producto:
                                                                if ((ProductoData.lapicesColores.getStock() - unidadesAComprar) < 0) {
                                                                    System.out.println("La cantidad introducida no es válida. Quedan " +
                                                                            ProductoData.lapicesColores.getStock() + " unidades de este producto.");
                                                                    cantidadValida = false;
                                                                } else {
                                                                    //comprueba si el primer producto está vacío
                                                                    if (producto1pe2c2 == null) {
                                                                        producto1pe2c2 = new Producto(ProductoData.lapicesColores);
                                                                        producto1pe2c2.setCantidad(unidadesAComprar);
                                                                        pedido2c2.setProducto1(producto1pe2c2);
                                                                        producto1pe2c2.restaStock(ProductoData.lapicesColores, unidadesAComprar);
                                                                    }
                                                                    //comprueba si el segundo producto está vacío
                                                                    else if (producto2pe2c2 == null) {
                                                                        producto2pe2c2 = new Producto(ProductoData.lapicesColores);
                                                                        producto2pe2c2.setCantidad(unidadesAComprar);
                                                                        pedido2c2.setProducto2(producto2pe2c2);
                                                                        producto2pe2c2.restaStock(ProductoData.lapicesColores, unidadesAComprar);
                                                                    } else {
                                                                        //finalmente, lo asigna al tercer producto
                                                                        producto3pe2c2 = new Producto(ProductoData.lapicesColores);
                                                                        producto3pe2c2.setCantidad(unidadesAComprar);
                                                                        pedido2c2.setProducto3(producto3pe2c2);
                                                                        producto3pe2c2.restaStock(ProductoData.lapicesColores, unidadesAComprar);
                                                                    }
                                                                    //texto final para concluir la inclusión del producto al pedido:
                                                                    Utils.incluirAlPedido();
                                                                    System.out.println(" · PRODUCTO AÑADIDO EXITOSAMENTE ·");
                                                                }

                                                            } while (!cantidadValida);
                                                        }
                                                        break;
                                                    case "003": //Incluir rotuladores
                                                        //comprueba si los productos están ocupados:
                                                        if (producto1pe2c2 != null && producto2pe2c2 != null && producto3pe2c2 != null)
                                                            System.out.println("     · NO PUEDES INCLUIR MÁS PRODUCTOS A TU PEDIDO · ");
                                                        else {
                                                            do {
                                                                cantidadValida = true;
                                                                System.out.print("Cuántas unidades desea comprar: ");
                                                                unidadesAComprar = Integer.parseInt(s.nextLine());  //TODO OJO!! PUEDE PETAR SI METES UNA LETRA, AVISADOS ESTÁIS
                                                                //comprueba si la cantidad que se desea comprar es posible por el stock del producto:
                                                                if ((ProductoData.rotuladores.getStock() - unidadesAComprar) < 0) {
                                                                    System.out.println("La cantidad introducida no es válida. Quedan " +
                                                                            ProductoData.rotuladores.getStock() + " unidades de este producto.");
                                                                    cantidadValida = false;
                                                                } else {
                                                                    //comprueba si el primer producto está vacío
                                                                    if (producto1pe2c2 == null) {
                                                                        producto1pe2c2 = new Producto(ProductoData.rotuladores);
                                                                        producto1pe2c2.setCantidad(unidadesAComprar);
                                                                        pedido2c2.setProducto1(producto1pe2c2);
                                                                        producto1pe2c2.restaStock(ProductoData.rotuladores, unidadesAComprar);
                                                                    }
                                                                    //comprueba si el segundo producto está vacío
                                                                    else if (producto2pe2c2 == null) {
                                                                        producto2pe2c2 = new Producto(ProductoData.rotuladores);
                                                                        producto2pe2c2.setCantidad(unidadesAComprar);
                                                                        pedido2c2.setProducto2(producto2pe2c2);
                                                                        producto2pe2c2.restaStock(ProductoData.rotuladores, unidadesAComprar);
                                                                    } else {
                                                                        //finalmente, lo asigna al tercer producto
                                                                        producto3pe2c2 = new Producto(ProductoData.rotuladores);
                                                                        producto3pe2c2.setCantidad(unidadesAComprar);
                                                                        pedido2c2.setProducto3(producto3pe2c2);
                                                                        producto3pe2c2.restaStock(ProductoData.rotuladores, unidadesAComprar);
                                                                    }
                                                                    //texto final para concluir la inclusión del producto al pedido:
                                                                    Utils.incluirAlPedido();
                                                                    System.out.println(" · PRODUCTO AÑADIDO EXITOSAMENTE ·");
                                                                }
                                                            } while (!cantidadValida);
                                                        }
                                                        break;
                                                    case "004": //Incluir estuche
                                                        //comprueba si los productos están ocupados:
                                                        if (producto1pe2c2 != null && producto2pe2c2 != null && producto3pe2c2 != null)
                                                            System.out.println("     · NO PUEDES INCLUIR MÁS PRODUCTOS A TU PEDIDO · ");
                                                        else {
                                                            do {
                                                                cantidadValida = true;
                                                                System.out.print("Cuántas unidades desea comprar: ");
                                                                unidadesAComprar = Integer.parseInt(s.nextLine());  //TODO OJO!! PUEDE PETAR SI METES UNA LETRA, AVISADOS ESTÁIS
                                                                //comprueba si la cantidad que se desea comprar es posible por el stock del producto:
                                                                if ((ProductoData.estuche.getStock() - unidadesAComprar) < 0) {
                                                                    System.out.println("La cantidad introducida no es válida. Quedan " +
                                                                            ProductoData.estuche.getStock() + " unidades de este producto.");
                                                                    cantidadValida = false;
                                                                } else {
                                                                    //comprueba si el primer producto está vacío
                                                                    if (producto1pe2c2 == null) {
                                                                        producto1pe2c2 = new Producto(ProductoData.estuche);
                                                                        producto1pe2c2.setCantidad(unidadesAComprar);
                                                                        pedido2c2.setProducto1(producto1pe2c2);
                                                                        producto1pe2c2.restaStock(ProductoData.estuche, unidadesAComprar);
                                                                    }
                                                                    //comprueba si el segundo producto está vacío
                                                                    else if (producto2pe2c2 == null) {
                                                                        producto2pe2c2 = new Producto(ProductoData.estuche);
                                                                        producto2pe2c2.setCantidad(unidadesAComprar);
                                                                        pedido2c2.setProducto2(producto2pe2c2);
                                                                        producto2pe2c2.restaStock(ProductoData.estuche, unidadesAComprar);
                                                                    } else {
                                                                        //finalmente, lo asigna al tercer producto
                                                                        producto3pe2c2 = new Producto(ProductoData.estuche);
                                                                        producto3pe2c2.setCantidad(unidadesAComprar);
                                                                        pedido2c2.setProducto3(producto3pe2c2);
                                                                        producto3pe2c2.restaStock(ProductoData.estuche, unidadesAComprar);
                                                                    }
                                                                    //texto final para concluir la inclusión del producto al pedido:
                                                                    Utils.incluirAlPedido();
                                                                    System.out.println("    · PRODUCTO AÑADIDO EXITOSAMENTE ·");
                                                                }
                                                            } while (!cantidadValida);
                                                        }
                                                        break;
                                                    case "005": //Incluir folios
                                                        //comprueba si los productos están ocupados:
                                                        if (producto1pe2c2 != null && producto2pe2c2 != null && producto3pe2c2 != null)
                                                            System.out.println("     · NO PUEDES INCLUIR MÁS PRODUCTOS A TU PEDIDO · ");
                                                        else {
                                                            do {
                                                                cantidadValida = true;
                                                                System.out.print("Cuántas unidades desea comprar: ");
                                                                unidadesAComprar = Integer.parseInt(s.nextLine());  //TODO OJO!! PUEDE PETAR SI METES UNA LETRA, AVISADOS ESTÁIS
                                                                //comprueba si la cantidad que se desea comprar es posible por el stock del producto:
                                                                if ((ProductoData.folios.getStock() - unidadesAComprar) < 0) {
                                                                    System.out.println("La cantidad introducida no es válida. Quedan " +
                                                                            ProductoData.folios.getStock() + " unidades de este producto.");
                                                                    cantidadValida = false;
                                                                } else {
                                                                    //comprueba si el primer producto está vacío
                                                                    if (producto1pe2c2 == null) {
                                                                        producto1pe2c2 = new Producto(ProductoData.folios);
                                                                        producto1pe2c2.setCantidad(unidadesAComprar);
                                                                        pedido2c2.setProducto1(producto1pe2c2);
                                                                        producto1pe2c2.restaStock(ProductoData.folios, unidadesAComprar);
                                                                    }
                                                                    //comprueba si el segundo producto está vacío
                                                                    else if (producto2pe2c2 == null) {
                                                                        producto2pe2c2 = new Producto(ProductoData.folios);
                                                                        producto2pe2c2.setCantidad(unidadesAComprar);
                                                                        pedido2c2.setProducto2(producto2pe2c2);
                                                                        producto2pe2c2.restaStock(ProductoData.folios, unidadesAComprar);
                                                                    } else {
                                                                        //finalmente, lo asigna al tercer producto
                                                                        producto3pe2c2 = new Producto(ProductoData.folios);
                                                                        producto3pe2c2.setCantidad(unidadesAComprar);
                                                                        pedido2c2.setProducto3(producto3pe2c2);
                                                                        producto3pe2c2.restaStock(ProductoData.folios, unidadesAComprar);
                                                                    }
                                                                    //texto final para concluir la inclusión del producto al pedido:
                                                                    Utils.incluirAlPedido();
                                                                    System.out.println("     · PRODUCTO AÑADIDO EXITOSAMENTE ·");
                                                                }
                                                            } while (!cantidadValida);
                                                        }
                                                        break;
                                                    case "006": //Incluir mochila
                                                        //comprueba si los productos están ocupados:
                                                        if (producto1pe2c2 != null && producto2pe2c2 != null && producto3pe2c2 != null)
                                                            System.out.println("     · NO PUEDES INCLUIR MÁS PRODUCTOS A TU PEDIDO · ");
                                                        else {
                                                            do {
                                                                cantidadValida = true;
                                                                System.out.print("Cuántas unidades desea comprar: ");
                                                                unidadesAComprar = Integer.parseInt(s.nextLine());  //TODO OJO!! PUEDE PETAR SI METES UNA LETRA, AVISADOS ESTÁIS
                                                                //comprueba si la cantidad que se desea comprar es posible por el stock del producto:
                                                                if ((ProductoData.mochila.getStock() - unidadesAComprar) < 0) {
                                                                    System.out.println("La cantidad introducida no es válida. Quedan " +
                                                                            ProductoData.mochila.getStock() + " unidades de este producto.");
                                                                    cantidadValida = false;
                                                                } else {
                                                                    //comprueba si el primer producto está vacío
                                                                    if (producto1pe2c2 == null) {
                                                                        producto1pe2c2 = new Producto(ProductoData.mochila);
                                                                        producto1pe2c2.setCantidad(unidadesAComprar);
                                                                        pedido2c2.setProducto1(producto1pe2c2);
                                                                        producto1pe2c2.restaStock(ProductoData.mochila, unidadesAComprar);
                                                                    }
                                                                    //comprueba si el segundo producto está vacío
                                                                    else if (producto2pe2c2 == null) {
                                                                        producto2pe2c2 = new Producto(ProductoData.mochila);
                                                                        producto2pe2c2.setCantidad(unidadesAComprar);
                                                                        pedido2c2.setProducto2(producto2pe2c2);
                                                                        producto2pe2c2.restaStock(ProductoData.mochila, unidadesAComprar);
                                                                    } else {
                                                                        //finalmente, lo asigna al tercer producto
                                                                        producto3pe2c2 = new Producto(ProductoData.mochila);
                                                                        producto3pe2c2.setCantidad(unidadesAComprar);
                                                                        pedido2c2.setProducto3(producto3pe2c2);
                                                                        producto3pe2c2.restaStock(ProductoData.mochila, unidadesAComprar);
                                                                    }
                                                                    //texto final para concluir la inclusión del producto al pedido:
                                                                    Utils.incluirAlPedido();
                                                                    System.out.println("    · PRODUCTO AÑADIDO EXITOSAMENTE ·");
                                                                }
                                                            } while (!cantidadValida);
                                                        }
                                                        break;
                                                    case "007": //Incluir libro1
                                                        //comprueba si los productos están ocupados:
                                                        if (producto1pe2c2 != null && producto2pe2c2 != null && producto3pe2c2 != null)
                                                            System.out.println("     · NO PUEDES INCLUIR MÁS PRODUCTOS A TU PEDIDO · ");
                                                        else {
                                                            do {
                                                                cantidadValida = true;
                                                                System.out.print("Cuántas unidades desea comprar: ");
                                                                unidadesAComprar = Integer.parseInt(s.nextLine());  //TODO OJO!! PUEDE PETAR SI METES UNA LETRA, AVISADOS ESTÁIS
                                                                //comprueba si la cantidad que se desea comprar es posible por el stock del producto:
                                                                if ((ProductoData.libro1.getStock() - unidadesAComprar) < 0) {
                                                                    System.out.println("La cantidad introducida no es válida. Quedan " +
                                                                            ProductoData.libro1.getStock() + " unidades de este producto.");
                                                                    cantidadValida = false;
                                                                } else {
                                                                    //comprueba si el primer producto está vacío
                                                                    if (producto1pe2c2 == null) {
                                                                        producto1pe2c2 = new Producto(ProductoData.libro1);
                                                                        producto1pe2c2.setCantidad(unidadesAComprar);
                                                                        pedido2c2.setProducto1(producto1pe2c2);
                                                                        producto1pe2c2.restaStock(ProductoData.libro1, unidadesAComprar);
                                                                    }
                                                                    //comprueba si el segundo producto está vacío
                                                                    else if (producto2pe2c2 == null) {
                                                                        producto2pe2c2 = new Producto(ProductoData.libro1);
                                                                        producto2pe2c2.setCantidad(unidadesAComprar);
                                                                        pedido2c2.setProducto2(producto2pe2c2);
                                                                        producto2pe2c2.restaStock(ProductoData.libro1, unidadesAComprar);
                                                                    } else {
                                                                        //finalmente, lo asigna al tercer producto
                                                                        producto3pe2c2 = new Producto(ProductoData.libro1);
                                                                        producto3pe2c2.setCantidad(unidadesAComprar);
                                                                        pedido2c2.setProducto3(producto3pe2c2);
                                                                        producto3pe2c2.restaStock(ProductoData.libro1, unidadesAComprar);
                                                                    }
                                                                    //texto final para concluir la inclusión del producto al pedido:
                                                                    Utils.incluirAlPedido();
                                                                    System.out.println("     · PRODUCTO AÑADIDO EXITOSAMENTE ·");
                                                                }
                                                            } while (!cantidadValida);
                                                        }
                                                        break;
                                                    case "008": //Incluir libro2
                                                        //comprueba si los productos están ocupados:
                                                        if (producto1pe2c2 != null && producto2pe2c2 != null && producto3pe2c2 != null)
                                                            System.out.println("     · NO PUEDES INCLUIR MÁS PRODUCTOS A TU PEDIDO · ");
                                                        else {
                                                            do {
                                                                cantidadValida = true;
                                                                System.out.print("Cuántas unidades desea comprar: ");
                                                                unidadesAComprar = Integer.parseInt(s.nextLine());  //TODO OJO!! PUEDE PETAR SI METES UNA LETRA, AVISADOS ESTÁIS
                                                                //comprueba si la cantidad que se desea comprar es posible por el stock del producto:
                                                                if ((ProductoData.libro2.getStock() - unidadesAComprar) < 0) {
                                                                    System.out.println("La cantidad introducida no es válida. Quedan " +
                                                                            ProductoData.libro2.getStock() + " unidades de este producto.");
                                                                    cantidadValida = false;
                                                                } else {
                                                                    //comprueba si el primer producto está vacío
                                                                    if (producto1pe2c2 == null) {
                                                                        producto1pe2c2 = new Producto(ProductoData.libro2);
                                                                        producto1pe2c2.setCantidad(unidadesAComprar);
                                                                        pedido2c2.setProducto1(producto1pe2c2);
                                                                        producto1pe2c2.restaStock(ProductoData.libro2, unidadesAComprar);
                                                                    }
                                                                    //comprueba si el segundo producto está vacío
                                                                    else if (producto2pe2c2 == null) {
                                                                        producto2pe2c2 = new Producto(ProductoData.libro2);
                                                                        producto2pe2c2.setCantidad(unidadesAComprar);
                                                                        pedido2c2.setProducto2(producto2pe2c2);
                                                                        producto2pe2c2.restaStock(ProductoData.libro2, unidadesAComprar);
                                                                    } else {
                                                                        //finalmente, lo asigna al tercer producto
                                                                        producto3pe2c2 = new Producto(ProductoData.libro2);
                                                                        producto3pe2c2.setCantidad(unidadesAComprar);
                                                                        pedido2c2.setProducto3(producto3pe2c2);
                                                                        producto3pe2c2.restaStock(ProductoData.libro2, unidadesAComprar);
                                                                    }
                                                                    //texto final para concluir la inclusión del producto al pedido:
                                                                    Utils.incluirAlPedido();
                                                                    System.out.println("     · PRODUCTO AÑADIDO EXITOSAMENTE ·");
                                                                }
                                                            } while (!cantidadValida);
                                                        }
                                                        break;
                                                    default:
                                                        if (!op4.equalsIgnoreCase("no"))
                                                            System.out.println("Opción introducida incorrecta. Pruebe de nuevo.");
                                                }
                                            } while (!op4.equalsIgnoreCase("no"));
                                            //seteamos el pedido creado al cliente correspondiente
                                            cliente2.setPedido2(pedido2c2);
                                        } else
                                            System.out.println(" - NO PUEDES HACER MÁS PEDIDOS, CONSULTA EL ESTADO DE TUS PEDIDOS EN EL MENÚ ANTERIOR - ");
                                    }
                                    break;

                                case "3":
                                    //VER MIS PEDIDOS REALIZADOS
                                    if ((cliente2 == null || (cliente1.getEmail().equals(email) && cliente1.getClave().equals(clave)))) {
                                        if (pedido1c1 == null && pedido2c1 == null)
                                            System.out.println("    · NO TIENE NINGÚN PEDIDO REALIZADO ·");
                                        else {
                                            //mostrar todos los pedidos que no estén a null
                                            if (pedido1c1 != null) {
                                                System.out.print(pedido1c1.pintaPedido(pedido1c1, cliente1));
                                                Utils.pulsaParaContinuar();
                                            }
                                            if (pedido2c1 != null) {
                                                System.out.print(pedido2c1.pintaPedido(pedido2c1, cliente1));
                                                Utils.pulsaParaContinuar();
                                            }
                                        }
                                    } else {
                                        if (pedido1c2 == null && pedido2c2 == null)
                                            System.out.println("    · NO TIENE NINGÚN PEDIDO REALIZADO ·");
                                        else {
                                            //mostrar todos los pedidos que no estén a null
                                            if (pedido1c2 != null) {
                                                System.out.print(pedido1c2.pintaPedido(pedido1c2, cliente2));
                                                Utils.pulsaParaContinuar();
                                            }
                                            if (pedido2c2 != null) {
                                                System.out.print(pedido2c2.pintaPedido(pedido2c2, cliente2));
                                                Utils.pulsaParaContinuar();
                                            }
                                        }
                                    }
                                    break;

                                case "4":
                                    //VER MIS DATOS PERSONALES
                                    //Comprueba si cliente2 es null para pintar los datos del cliente que se registra.
                                    if ((cliente2 == null || (cliente1.getEmail().equals(email) && cliente1.getClave().equals(clave))))
                                        System.out.println(cliente1.pintaCliente());
                                    else System.out.println(cliente2.pintaCliente());
                                    Utils.pulsaParaContinuar();
                                    break;

                                case "5":
                                    //MODIFICAR MIS DATOS PERSONALES
                                    do {
                                        Menus.menuCambiarDatos();
                                        System.out.print("Elija el dato que desea cambiar: ");
                                        op3 = s.nextLine();
                                        switch (op3) {
                                            case "1":
                                                //EMAIL
                                                do {
                                                    System.out.print("·Introduzca el nuevo email: ");
                                                    email = s.nextLine();
                                                    if (Cliente.validarEmail(email)) {
                                                        if ((cliente2 == null || (cliente1.getEmail().equals(email) && cliente1.getClave().equals(clave))))
                                                            cliente1.setEmail(email);
                                                        else cliente2.setEmail(email);
                                                    } else
                                                        System.out.println("    · NO SE HA PODIDO MODIFICAR EL EMAIL, VUELVA A INTENTARLO · ");
                                                } while (!Cliente.validarEmail(email));
                                                Utils.mensajeDatoModificado();
                                                break;

                                            case "2":
                                                //CLAVE
                                                do {
                                                    System.out.print("·Introduzca la nueva contraseña: ");
                                                    clave1 = s.nextLine();
                                                    System.out.print("·Vuelva a introducir la nueva contraseña: ");
                                                    clave2 = s.nextLine();
                                                    if (Cliente.validaClave(clave1, clave2)) {
                                                        if ((cliente2 == null || (cliente1.getEmail().equals(email) && cliente1.getClave().equals(clave))))
                                                            cliente1.setClave(clave1);
                                                        else cliente2.setClave(clave1);
                                                    } else
                                                        System.out.println("    · LAS CONTRASEÑAS NO COINCIDEN, VUELVA A INTENTARLO · ");
                                                } while (!Cliente.validaClave(clave1, clave2));
                                                Utils.mensajeDatoModificado();
                                                break;

                                            case "3":
                                                //NOMBRE
                                                do {
                                                    System.out.print("·Introduzca el nuevo nombre: ");
                                                    nombre = s.nextLine();
                                                    nombreModificado = nombre.substring(0, 1).toUpperCase() + nombre.substring(1).toLowerCase();
                                                    nombre = nombreModificado;
                                                    if (Cliente.validaNombre(nombre)) {
                                                        if ((cliente2 == null || (cliente1.getEmail().equals(email) && cliente1.getClave().equals(clave))))
                                                            cliente1.setNombre(nombre);
                                                        else cliente2.setNombre(nombre);
                                                    } else
                                                        System.out.println("    · NO SE HA PODIDO MODIFICAR EL NOMBRE, VUELVA A INTENTARLO · ");
                                                } while (!Cliente.validaNombre(nombre));
                                                Utils.mensajeDatoModificado();
                                                break;

                                            case "4":
                                                //APELLIDO
                                                do {
                                                    System.out.print("Introduzca el nuevo apellido: ");
                                                    apellido = s.nextLine();
                                                    apellidoModificado = apellido.substring(0, 1).toUpperCase() + apellido.substring(1).toLowerCase();
                                                    apellido = apellidoModificado;
                                                    if (Cliente.validaApellido(apellido)) {
                                                        if ((cliente2 == null || (cliente1.getEmail().equals(email) && cliente1.getClave().equals(clave))))
                                                            cliente1.setApellido(apellido);
                                                        else cliente2.setApellido(apellido);
                                                    } else
                                                        System.out.println("    · NO SE HA PODIDO MODIFICAR EL APELLIDO, VUELVA A INTENTARLO · ");
                                                } while (!Cliente.validaApellido(apellido));
                                                Utils.mensajeDatoModificado();
                                                break;

                                            case "5":
                                                //DNI
                                                do {
                                                    System.out.print("Introduzca el nuevo DNI: ");
                                                    dni = s.nextLine();
                                                    if (Cliente.validaDNI(dni)) {
                                                        if ((cliente2 == null || (cliente1.getEmail().equals(email) && cliente1.getClave().equals(clave))))
                                                            cliente1.setDni(dni);
                                                        else cliente2.setDni(dni);
                                                    } else
                                                        System.out.println("    · NO SE HA PODIDO MODIFICAR EL ID, VUELVA A INTENTARLO · ");
                                                } while (!Cliente.validaDNI(dni));
                                                Utils.mensajeDatoModificado();
                                                break;

                                            case "6":
                                                //DIRECCIÓN
                                                do {
                                                    System.out.print("Introduzca la nueva dirección: ");
                                                    direccion = s.nextLine();
                                                    direccionModificado = direccion.substring(0, 1).toUpperCase() + direccion.substring(1).toLowerCase();
                                                    direccion = direccionModificado;
                                                    if (!Cliente.validaDireccion(direccion)) {
                                                        if ((cliente2 == null || (cliente1.getEmail().equals(email) && cliente1.getClave().equals(clave))))
                                                            cliente1.setDireccion(direccion);
                                                        else cliente2.setDireccion(direccion);
                                                    } else
                                                        System.out.println("    · NO SE HA PODIDO MODIFICAR LA DIRECCIÓN, VUELVA A INTENTARLO · ");
                                                } while (Cliente.validaDireccion(direccion));
                                                Utils.mensajeDatoModificado();
                                                break;

                                            case "7":
                                                //LOCALIDAD
                                                do {
                                                    System.out.print("Introduzca la nueva localidad: ");
                                                    localidad = s.nextLine();
                                                    localidadModificada = localidad.substring(0, 1).toUpperCase() + localidad.substring(1).toLowerCase();
                                                    localidad = localidadModificada;
                                                    if (!Cliente.validaLocalidad(localidad)) {
                                                        if ((cliente2 == null || (cliente1.getEmail().equals(email) && cliente1.getClave().equals(clave))))
                                                            cliente1.setLocalidad(localidad);
                                                        else cliente2.setLocalidad(localidad);
                                                    } else
                                                        System.out.println("    · NO SE HA PODIDO MODIFICAR LA LOCALIDAD, VUELVA A INTENTARLO · ");
                                                } while (Cliente.validaLocalidad(localidad));
                                                Utils.mensajeDatoModificado();
                                                break;

                                            case "8":
                                                //PROVINCIA
                                                do {
                                                    System.out.print("Introduzca la nueva provincia: ");
                                                    provincia = s.nextLine();
                                                    provinciaModificada = provincia.substring(0, 1).toUpperCase() + provincia.substring(1).toLowerCase();
                                                    provincia = provinciaModificada;
                                                    if (!Cliente.validaProvincia(provincia)) {
                                                        if ((cliente2 == null || (cliente1.getEmail().equals(email) && cliente1.getClave().equals(clave))))
                                                            cliente1.setProvincia(provincia);
                                                        else cliente2.setProvincia(provincia);
                                                    } else
                                                        System.out.println("    · NO SE HA PODIDO MODIFICAR LA PROVINCIA, VUELVA A INTENTARLO · ");
                                                } while (Cliente.validaProvincia(provincia));
                                                Utils.mensajeDatoModificado();
                                                break;

                                            case "9":
                                                //TELÉFONO
                                                do {
                                                    System.out.print("Introduzca el nuevo teléfono: ");
                                                    telefono = s.nextLine();
                                                    if (Cliente.validaTelefono(telefono)) {
                                                        if ((cliente2 == null || (cliente1.getEmail().equals(email) && cliente1.getClave().equals(clave))))
                                                            cliente1.setTelefono(telefono);
                                                        else cliente2.setTelefono(telefono);
                                                    } else
                                                        System.out.println("    · NO SE HA PODIDO MODIFICAR EL TELÉFONO, VUELVA A INTENTARLO · ");
                                                } while (!Cliente.validaTelefono(telefono));
                                                Utils.mensajeDatoModificado();
                                                break;

                                            case "10":
                                                //Salir del menu cambiar datos
                                                Utils.saliendo();
                                                break;

                                            default:
                                                System.out.println("  · Opción introducida incorrecta, vuelva a probar ·");
                                        }
                                    } while (!op3.equals("10"));

                                    break;

                                case "6":
                                    //CERRAR SESIÓN
                                    Utils.cerrandoSesion();
                                    break;

                                default:
                                    System.out.println("  · Opción Introducida Incorrecta, vuelva a probar ·");
                            }
                        } while (!op2.equals("6"));
                    }
                    esTrabajador1 = false;
                    esTrabajador2 = false;
                    esTrabajador3 = false;
                    esAdministrador = false;
                    break;


                //Salir:
                case "3":
                    Utils.saliendo();
                    Utils.limpiaPantalla();
                    break;

                default:
                    System.out.println("Opción introducida incorrecta. Vuelva a intentarlo.\n");
            }
        } while (!op1.equals("3"));
    }
}