package data;

import models.Producto;

public class ProductoData {

    // LISTA DE PRODUCTOS: Libreta, Set de 24 Lápices de Colores, Set de 12 Rotuladores, Estuche,
    // Pack de Folios A4, Mochila Escolar, Libro de Iniciación a la Programación, Libro Clean Code para Java.

    public static Producto libreta = new Producto("P01_Libreta_MZ",
            "Libreta", 2.99f, 20);
    public static Producto lapicesColores = new Producto("P02_LapicesColores_MZ",
            "Set de 24 Lápices de Colores", 15f, 20);
    public static Producto rotuladores = new Producto("P03_Rotuladores_MZ",
            "Set de 12 Rotuladores", 8.50f, 20);
    public static Producto estuche = new Producto("P04_Estuche_MZ",
            "Estuche Escolar", 3.50f, 20);
    public static Producto folios = new Producto("P05_Folios_MZ",
            "Pack de Folios A4 - 500ud", 5.95f, 20);
    public static Producto mochila = new Producto("P06_Mochila_MZ",
            "Mochila Escolar", 12.90f, 20);
    public static Producto libro1 = new Producto("P07_Libro1_MZ",
            "Libro de Iniciación a la Programación", 22.50f, 20);
    public static Producto libro2 = new Producto("P08_Libro2_MZ",
            "Libro Clean Code para Java", 18.95f, 20);




    public static boolean validaStockModificado(String datoModificado){
        if (datoModificado.isEmpty()) return false;
        else {
            for (int i = 0; i < datoModificado.length(); i++) {
                if (Character.isDigit(datoModificado.charAt(i))) return true;
            }
        }
        return false;
    }

    public static boolean validaPrecioModificado(String datoModificado){
        if (datoModificado.isEmpty()) return false;
        return Float.parseFloat(datoModificado) >= 0;
    }




    public static boolean cambiaDatosProducto(Producto producto, String opcion, String datoModificado){
            if (opcion.equalsIgnoreCase("1")){
                producto.setNombre(datoModificado);
                return true;
            }
            if (opcion.equalsIgnoreCase("2") && validaPrecioModificado(datoModificado)){
                producto.setPrecio(Float.parseFloat(datoModificado));
                return true;
            }
            if (opcion.equalsIgnoreCase("3") && validaStockModificado(datoModificado)){
                producto.setStock(Integer.parseInt(datoModificado));
                return true;
            }
            return false;
    }

    //TO STRING CATÁLOGO DE PRODUCTOS:
    public static String pintaProductos() {
        return "\n" +
                "╔═════════════════════════════════════════════════════════════════════════════════════╗\n" +
                "║ =========================      CATÁLOGO DE PRODUCTOS      ========================= ║\n" +
                "╠═══════╦════════════════════════════════════════════╦══════════════════╦═════════════╣\n" +
                "║   Nº  ║                    NOMBRE                  ║      PRECIO      ║    STOCK    ║\n" +
                "╠═══════╬════════════════════════════════════════════╬══════════════════╬═════════════╣\n" +
                String.format("║  %-4s ║ %-42s ║ %11.2fE     ║ %11s ║%n", "001", libreta.getNombre(), libreta.getPrecio(), ((libreta.getStock() < 1)? "SIN STOCK" : libreta.getStock())) +
                String.format("║  %-4s ║ %-42s ║ %11.2fE     ║ %11s ║%n", "002", lapicesColores.getNombre(), lapicesColores.getPrecio(), ((lapicesColores.getStock() < 1)? "SIN STOCK" : lapicesColores.getStock())) +
                String.format("║  %-4s ║ %-42s ║ %11.2fE     ║ %11s ║%n", "003", rotuladores.getNombre(), rotuladores.getPrecio(), ((rotuladores.getStock() < 1)? "SIN STOCK" : rotuladores.getStock())) +
                String.format("║  %-4s ║ %-42s ║ %11.2fE     ║ %11s ║%n", "004", estuche.getNombre(), estuche.getPrecio(), ((estuche.getStock() < 1)? "SIN STOCK" : estuche.getStock())) +
                String.format("║  %-4s ║ %-42s ║ %11.2fE     ║ %11s ║%n", "005", folios.getNombre(), folios.getPrecio(), ((folios.getStock() < 1)? "SIN STOCK" : folios.getStock())) +
                String.format("║  %-4s ║ %-42s ║ %11.2fE     ║ %11s ║%n", "006", mochila.getNombre(), mochila.getPrecio(), ((mochila.getStock() < 1)? "SIN STOCK" : mochila.getStock())) +
                String.format("║  %-4s ║ %-42s ║ %11.2fE     ║ %11s ║%n", "007", libro1.getNombre(), libro1.getPrecio(), ((libro1.getStock() < 1)? "SIN STOCK" : libro1.getStock())) +
                String.format("║  %-4s ║ %-42s ║ %11.2fE     ║ %11s ║%n", "008", libro2.getNombre(), libro2.getPrecio(), ((libro2.getStock() < 1)? "SIN STOCK" : libro2.getStock())) +
                "╚═══════╩════════════════════════════════════════════╩══════════════════╩═════════════╝\n";
    }
}
