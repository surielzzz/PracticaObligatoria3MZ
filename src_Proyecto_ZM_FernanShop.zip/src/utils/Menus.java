package utils;

import models.Pedido;

public class Menus {

    public static void logo() {
        System.out.println("""
                ╔═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╗
                ║  ╔═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╗  ║
                ║  ║                                                                                                                               ║  ║
                ║  ║          ^                                                                                                         ^          ║  ║
                ║  ║         / \\                                                                                                       / \\         ║  ║
                ║  ║        /___\\        ███████╗███████╗██████╗ ███╗   ██╗ █████╗ ███╗   ██╗███████╗██╗  ██╗ ██████╗ ██████╗         /___\\        ║  ║
                ║  ║        |   |        ██╔════╝██╔════╝██╔══██╗████╗  ██║██╔══██╗████╗  ██║██╔════╝██║  ██║██╔═══██╗██╔══██╗        |   |        ║  ║
                ║  ║        |   |        █████╗  █████╗  ██████╔╝██╔██╗ ██║███████║██╔██╗ ██║███████╗███████║██║   ██║██████╔╝        |   |        ║  ║
                ║  ║        |   |        ██╔══╝  ██╔══╝  ██╔══██╗██║╚██╗██║██╔══██║██║╚██╗██║╚════██║██╔══██║██║   ██║██╔═══╝         |   |        ║  ║
                ║  ║        |___|        ██║     ███████╗██║  ██║██║ ╚████║██║  ██║██║ ╚████║███████║██║  ██║╚██████╔╝██║             |___|        ║  ║
                ║  ║        |___|        ╚═╝     ╚══════╝╚═╝  ╚═╝╚═╝  ╚═══╝╚═╝  ╚═╝╚═╝  ╚═══╝╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚═╝             |___|        ║  ║
                ║  ║        |||||                                     ZAMIRA SURIEL y MIREYA CUETO                                    |||||        ║  ║
                ║  ║         \\_/                                                                                                       \\_/         ║  ║
                ║  ║                                                                                                                               ║  ║
                ║  ╚═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╝  ║
                ╚═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╝
                """);
    }

    public static void menuPrincipal() {
        System.out.println("""
                
                ╔══════════════════════════════════╗
                ║          MENÚ PRINCIPAL          ║
                ╠══════════════════════════════════╣
                ║       1. Iniciar sesión.         ║
                ║       2. Registrarse.            ║
                ║       3. Salir.                  ║
                ╚══════════════════════════════════╝
                """);
    }

    public static void menuCliente() {
        System.out.println("""
                
                ╔═════════════════════════════════════════════════╗
                ║       1. Consultar catálogo de productos.       ║
                ║       2. Realizar un pedido.                    ║
                ║       3. Ver mis pedidos realizados.            ║
                ║       4. Ver mis datos personales.              ║
                ║       5. Modificar mis datos personales.        ║
                ║       6. Cerrar sesión.                         ║
                ╚═════════════════════════════════════════════════╝
                """);
    }

    public static void menuCambiarDatos() {
        System.out.println("""
                
                ╔══════════════════════════╗
                ║       1. Email.          ║
                ║       2. Clave.          ║
                ║       3. Nombre.         ║
                ║       4. Apellido.       ║
                ║       5. DNI.            ║
                ║       6. Dirección.      ║
                ║       7. Localidad.      ║
                ║       8. Provincia.      ║
                ║       9. Teléfono.       ║
                ║      10. SALIR.          ║
                ╚══════════════════════════╝
                """);
    }

    public static void menuCambiaDatosTrabajador() {
        System.out.println("""
                
                ╔══════════════════════════╗
                ║       1. Email.          ║
                ║       2. Clave.          ║
                ║       3. Nombre.         ║
                ║       4. DNI.            ║
                ║       5. SALIR.          ║
                ╚══════════════════════════╝
                """);
    }

    public static void pintaOpcionesCambio(){
        System.out.println("""
                
                ╔═══════════════════════════╗
                ║     DATOS A MODIFICAR     ║
                ╠═══════════════════════════╣
                ║       1 - Nombre          ║
                ║       2 - Precio          ║
                ║       3 - Stock           ║
                ║       4 - Salir           ║
                ╚═══════════════════════════╝
                """);
    }

    public static void menuCambiaEstado() {
        System.out.println("""
                
                ╔═══════════════════════════════╗
                ║       1. En Preparación       ║
                ║       2. Enviado              ║
                ║       3. Cancelado            ║
                ║       4. Recibido             ║
                ║       5. Retrasado            ║
                ║       6. Salir                ║
                ╚═══════════════════════════════╝
                """);
    }

    public static void menuTrabajador(String nombre, int cantidadPedidos) {
        System.out.printf("""
                \n\t¡Bienvenido/a, %s! Tienes %d pedidos que gestionar.
                ╔═══════════════════════════════════════════════════════════════╗
                ║       1. Consultar los pedidos asignados.                     ║
                ║       2. Modificar los datos de un pedido.                    ║
                ║       3. Consultar el catálogo de productos.                  ║
                ║       4. Modificar un producto del catálogo.                  ║
                ║       5. Ver mi perfil.                                       ║
                ║       6. Modificar mis datos personales.                      ║
                ║       7. Cerrar sesión.                                       ║
                ╚═══════════════════════════════════════════════════════════════╝
                """, nombre, cantidadPedidos);
    }

    public static void menuAdministrador(String nombre, int pedidosPorAsignar) {
        System.out.printf("""
                \n\t¡Bienvenido, administrador %s!. %s
                ╔═══════════════════════════════════════════════════════╗
                ║       1. Asignar un pedido a un trabajador.           ║
                ║       2. Modificar el estado de un pedido.            ║
                ║       3. Dar de alta a un trabajador.                 ║
                ║       4. Ver todos los pedidos.                       ║
                ║       5. Ver todos los clientes.                      ║
                ║       6. Ver todos los trabajadores.                  ║
                ║       7. Cerrar sesión.                               ║
                ╚═══════════════════════════════════════════════════════╝
                """, nombre, (pedidosPorAsignar != 0) ? "Tienes " + pedidosPorAsignar + " pedidos por asignar." : "No tienes pedidos por asignar.");
    }
}
