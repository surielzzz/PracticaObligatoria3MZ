package utils;

import java.util.Scanner;

public class Utils {

    public static void pulsaParaContinuar() {
        System.out.print("Pulsa para continuar... ");
        new Scanner(System.in).nextLine();
        System.out.println();
    }

    public static void loading() {
        System.out.print("Cargando ");
        for (int i = 0; i < 4; i++) {
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            System.out.print(". ");
        }
        System.out.println();
    }

    public static void incluirAlPedido() {
        System.out.print("Añadiendo Al Pedido ");
        for (int i = 0; i < 4; i++) {
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            System.out.print(". ");
        }
        System.out.println();
    }

    public static void saliendo() {
        System.out.print("Saliendo ");
        for (int i = 0; i < 4; i++) {
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            System.out.print(". ");
        }
        System.out.println();
    }

    public static void cerrandoSesion() {
        System.out.print("Cerrando Sesión ");
        for (int i = 0; i < 4; i++) {
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            System.out.print(". ");
        }
        System.out.println();
    }

    public static void enter() {
        System.out.print("Pulsa ENTER ");
        new Scanner(System.in).nextLine();
    }

    public static void limpiaPantalla() {
        for (int i = 0; i < 100; i++) {
            System.out.println();
        }
    }

    public static void mensajeDatoModificado() {
        System.out.println(" · EL DATO HA SIDO MODIFICADO CON ÉXITO ·");
    }

}
